package com.cbe;

/**
 * Class QueryResult, each query generates a QueryResult object which contains the result and the filter used. <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class QueryResult {
 
  public QueryResult() {}

  /**
   * Filter can be used to see what container has been queried and other filter parameters. <br>
   */
  public Filter filter() {}

  /**
   * Returns a copy of a vector containing the items from the query.    <br>
   * The queryResult will update when new data comes in but the copy will not.<br>
   * If iterating make sure to create a variable for a local copy.<br>
   * @return vector&lt;CBE::ItemPtr&gt; contains the items matching the query.
   */
  public Items_Vec getItemsSnapshot() {}

  /**
   *  Returns # of items loaded in the queryResult.
   */
  public long itemsLoaded() {}

  /**
   *  total # items in the cloud matching the query result.  This may be more than loaded.
   */
  public long totalCount() {}

  /**
   *  Returns # of objects loaded in to the query result. 
   */
  public long objectsLoaded() {}

  /**
   *  Returns # of containers loaded in to the query result.
   */
  public long containersLoaded() {}

  /**
   *  Checks if the Item with id @param itemId, is in the query result. 
   */
  public boolean containsItem(long itemId) {}

}
