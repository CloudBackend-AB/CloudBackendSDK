package com.cbe;

/**
 * Class Member, Contains API:s for managing group members.
 * @author Cloudbackend <br>
 * @version 1.4.6 <br> 
 */
public class Member {

  /**
   * kick member.
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   */
  public void kick(String kickComment, GroupEventProtocol delegate) {}

  /**
   * ban member.
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   */
  public void ban(String banComment, GroupEventProtocol delegate) {}

  /**
   * un ban member
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   */
  public void unBan(GroupEventProtocol delegate) {}

  /**
   *  Returns member id.
   */
  public long memberId() {}

  /**
   *  Returns the member name.
   */
  public String name() {}

  /**
   *  Returns member visibility, private or public
   */
  public Visibility visibility() {}

  /**
   *  Returns group id that the member belongs to.
   */
  public long groupId() {}

  /**
   *  Returns ban information, BanInfo is a AbstractMap of 2 pairs where the key pair contains (banned member id, banned by member id) 
   *  and the value pair contains (banned time (unix), ban reason). <br> 
   */
  public BanInfo getMemberBanInfo() {}

  public Member() {}

}
