    /**
     * The CloudBackend delegates package for the SDK.
     * 
     * <p>
     * <b>Use:</b>
     * delegate threads for asynchronous handling of the callbacks from the cloud service.
     * </p>
     * @since 2.0
     */
    package com.cbe.delegate;
