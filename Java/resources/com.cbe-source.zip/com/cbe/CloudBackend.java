package com.cbe;
/**
 * class CloudBackend, Server/Edge Node API:s to login, query e.t.c. <br> 
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class CloudBackend {

  /**
   * This should return a instance of cloudbackend giving the user access to the root contianer and logIng in the user<br>
   * @param username of the user to be signed in<br>
   * @param password of the user to be signed in<br>
   * @param source is the identifier for the tenant<br>
   * @param delegate, AccountDelegate is a callback delegate to the user defined/implementation of the callbacks on AccountEventProtocol. <br>
   */
  public static CloudBackend logIn(String username, String password, String source, AccountEventProtocol delegate) {}

  /**
   * This should return a instance of cloudbackend giving the user access to the root contianer and logIng in the user<br>
   * @param username of the user to be signed in<br>
   * @param password of the user to be signed in<br>
   * @param source is the identifier for the tenant<br>
   * @param host can be set to our core v1.cloudbackend.com for now but in the future edge nodes and public cloud ip:s <br>
   * @param delegate, AccountDelegate is a callback delegate to the user defined implementation of the callbacks on AccountEventProtocol. <br>
   */
  public static CloudBackend logIn(String username, String password, String source, String host, AccountEventProtocol delegate) {}

  /**
   *  Source is not currently being used and should be fixed.<br>
   *  Call to create an account. Implement onCreated to from CBE::AccountDelegatePtrto recieve the<br>
   * callback. currently disabled<br>
   * @param username<br>
   * @param password<br>
   * @param email<br>
   * @param firstName<br>
   * @param lastName<br>
   * @param source<br>
   * @param delegate, AccountDelegate is a callback delegate to the user defined implementation of the callbacks on AccountEventProtocol. <br>
   */
  public static CloudBackend createAccount(String username, String password, String email, String firstName, String lastName, String source, AccountEventProtocol delegate) {}

  /**
   * adds a listner that will recieve updates as changes occur on the account.  removeListener should always be called when you stop using the delegate.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined implementation of the callbacks on ItemEventProtocol. <br>
   */
  public void addListener(ItemEventProtocol delegate) {}

  /**
   * removes a listner that will recieve updates as changes occur on the account<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined implementation of the callbacks on ItemEventProtocol. <br>
   */
  public void removeListener(ItemEventProtocol delegate) {}

  /**
   *  Call to get a list of items in the container. Implement onQueryLoaded to from CBE::ItemDelegatePtrto recieve the callback.  Requires you already signedIn.<br>
   * @param containerId<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined implementation of the callbacks on ItemEventProtocol. <br> 
   */
  public QueryChain query(long containerId, ItemEventProtocol delegate) {}

  /**
   *  Call to get a list of items in the container using a filter. Implement onQueryLoaded to from CBE::ItemEventProtocol to recieve the callback. Requires you already signedIn<br>
   *  Does not require a containerId due to having the filter.<br>
   * @param filter<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public QueryChain query(long containerId, Filter filter, ItemEventProtocol delegate) {}

  /**
   * Queries with a given path to the container or object given in the path<br>
   * @param relativePath, is the relative path from the queryRoot e.x /Documents/Pictures from a queryRoot that has the /Documents/Pictures containers.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   * @param queryRoot, is the Container id that will be the root of this query. Option to not add a id will resolve in rootContainer beeing the starting point.
   */
  public QueryChain queryWithPath(String relativePath, ItemEventProtocol delegate, long queryRoot) {}

  /**
   * Queries with a given path to the container or object given in the path<br>
   * @param relativePath, is the relative path from the queryRoot e.x /Documents/Pictures from a queryRoot that has the /Documents/Pictures containers.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   * 
   */
  public QueryChain queryWithPath(String relativePath, ItemEventProtocol delegate) {}

  /**
   * Search the whole container for tags related to Objects in the container structure. <br>
   * EX: Key = Name, Value Contract/Object/Song =&gt; Name:Contract1.<br>
   * <br>
   * Search handles tags in combination / conjunction of keys and/or key values seperated by |.<br>
   * EX: Name:*|Country:Sweden|Country:Norway, this would search for objects with key Name but any value and where key Country is either Sweden or Norway.<br>
   * @param tags is a string of key tags or key:value pairs that are seperated by |.<br>
   * @param containerId is the uint64_t id of the rootContainer to start the search of Objects in. ex: if starting in the rootContainer, the whole account will be searched for matching tags, key:value's.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>  
   */
  public QueryResult search(String tags, long containerId, ItemEventProtocol delegate) {}

  /**
   * Search the whole container for tags related to Objects in the container structure. <br>
   * EX: Key = Name, Value Contract/Object/Song =&gt; Name:Contract1.<br>
   * <br>
   * Search handles tags in combination / conjunction of keys and/or key values seperated by |.<br>
   * EX: Name:*|Country:Sweden|Country:Norway, this would search for objects with key Name but any value and where key Country is either Sweden or Norway.<br>
   * @param filter is a CBE::Filter on which you can set how you want data to be ordered when searching, remember to set the queryString to be keys/tags or key:value pairs that are seperated by |.<br>
   * @param containerId is the uint64_t id of the rootContainer to start the search of Objects in. ex: if starting in the rootContainer, the whole account will be searched for matching tags, key:value's.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public QueryResult search(Filter filter, long containerId, ItemEventProtocol delegate) {}

  /**
   * casts an item to a container.
   */
  public static Container castContainer(Item item) {}

  /**
   * casts an item to an object
   */
  public static Object castObject(Item item) {}

  /**
   * clears the cache to prevent memory issues in case of a very large cache.
   */
  public boolean clearCache() {}

  /**
   * Returns the account object with user account info.
  */
  public Account account() {}

  /**
   * Returns the version of the CloudBackend SDK. Can be used to report issues on the SDK.
   */
  public String version() {}

  /**
   *  Returns the groupManager object which list and search group apis are listed.
   */
  public GroupManager groupManager() {}

  /**
   *  Returns the shareManager object where list available and list my shares are available. 
   */
  public ShareManager shareManager() {}

}
