// XIOS/3 Boot Loader v3.0. 2018-04-25. Copyright XIOS/3 AB.

!function() {

  function initEnv() {

    // These are default global variables.
    const defaults = {
      locationHash : window.location.hash,
      locationHost : window.location.host,
      locationHostname : window.location.hostname,
      locationHref : window.location.href,
      locationProtocol : window.location.protocol,
      locationSearch : window.location.search,
    };
    for(let key in defaults) {
      if( window[key] === undefined ) {
        window[key] = defaults[key];
      }
    }
    const boot = {
      isIE : /Trident/i.test(navigator.userAgent),
      system : "xios/config/system.xml",
      startup : "xios/config/startup.xml",
      HTTPTimeout : 25000,
      locale : "en_US",

      doTrace : true,
      deDebug : false,

      // The amount of details stored in the trace log. Any of the
      // following values.
      //
      // ALL
      // TRACE
      // INFO
      // DEBUG
      // WARNING
      // ERROR
      // OFF
      traceLevel : "OFF",

      // If timestamps should be stored in the trace log. True or false.
      traceTimestamp : true,

      // If true
      // - skincreator import
      live : true,

      beforeInit : [],

      systemModules : {},
      components : {},
      operations : {},
      authenticators : {},
      adapters : {},
      addModule : function(name, obj) {
        if( this.systemModules[name] ) {
          console.log("Replacing module "+name);
        }
        this.systemModules[name] = obj;
      },
      addComponent : function(name, obj) {
        if( this.components[name] ) {
          console.log("Replacing component "+name);
        }
        this.components[name] = obj;
      },
      addOperation : function(name, obj) {
        if( this.operations[name] ) {
          console.log("Replacing operation "+name);
        }
        this.operations[name] = obj;
      },
      addAuthenticator : function(name, obj) {
        if( this.authenticators[name] ) {
          console.log("Replaceing authenticator "+name);
        }
        this.authenticators[name] = obj;
      },
      addAdapter : function(name, obj) {
        if( this.adapters[name] ) {
          console.log("Replacing adapter"+name);
        }
        this.adapters[name] = obj;
      }
    };
    if( window.boot === undefined ) {
      window.boot = {};
    }
    for(let key in boot) {
      if( window.boot[key] === undefined ) {
        window.boot[key] = boot[key];
      }
    }

    // Error reporting until context object is loaded.
    window.sys = {
      error : console.log,
    };
  }

  function _el(id) {
    return document.getElementById(id);
  }

  function initContainers() {
    if( !boot.win && !(boot.win=_el("win")) ) {
      document.body.style.overflow = "hidden";
      const e = document.createElement("iframe");
      e.id = e.name = "win";
      e.style = "position:absolute;left:0px;top:0px;width:100%;height:100%;border:0px";
      document.body.appendChild(e);
      boot.win = e;
    }

    {
      const e = document.createElement("div");
      e.id = "dragElt";
      e.style = "cursor:move;position:absolute;z-index:10000;left:1px;top:1px;width:0;height:0;border:1px dotted black;display:none;";
      document.body.appendChild(e);
    }
  }

  function conf_failure() {
    alert("Failed to load " + boot.config + ".");
  }

  let listeners = [];
  function addListener(obj, evt, cb) {
    obj.addEventListener(evt, cb);
    listeners.push([ obj, evt, cb ]);
  }

  function loadCSS(src) {
    if( boot.cacheKey ) {
      src += src.includes("?") ? "&" : "?";
      src += "version="+boot.cacheKey;
    }
    const el = document.createElement("link");
    el.setAttribute("rel", "stylesheet");
    el.setAttribute("type", "text/css");
//    addListener(el, "nload", loadedResource);
//    addListener(el, "error", loadedResource);
    el.setAttribute("href", src);
    document.head.appendChild(el);
  }

  function loadJS(src, cb) {
    if( boot.cacheKey ) {
      src += src.includes("?") ? "&" : "?";
      src += "version="+boot.cacheKey;
    }
    const script = document.createElement("script");
    script.defer = true;
    script.charset = "UTF-8";
    script.src = src;
    addListener(script, "load", cb);
    addListener(script, "error", cb);

    document.body.appendChild(script);
  }

  let resources = [];
  let dependentCodeLoading = false;
  let fileCount = 0;
  let filesLoaded = 0;
  function loadResources(evt) {

    if( evt ) {
      filesLoaded++;
      if( filesLoaded === fileCount ) {
        dependentCodeLoading = false;
      }
    }

    // if there are still files to load and the currently loading file
    // doesn't execute code onload
    if( fileCount < resources.length && !dependentCodeLoading ) {
      const href = resources[fileCount][0];
      dependentCodeLoading = resources[fileCount][1];
      // if the currently loading file doesn't have dependencies or it
      // is already loaded
      if( !dependentCodeLoading || filesLoaded<resources.length ) {
        fileCount++;
        loadJS(href, loadResources);
      }
    }
    if( filesLoaded===resources.length ) {
      finished();
    }
  }

  function selectResources(config) {
    const a = [
      [ "classes/class | components/component/dependencies/class[@href]",
        function(n) {
          return n.getAttribute("href");
        } ],
      [ "process/operation",

       function(n) {
         return "xios/system/script/operations/PO_" + n.getAttribute("name") + ".js";
       } ],
      [ "components/component[@href]",
        function(n) {
          return n.getAttribute("href");
        } ]
    ];
    const resourceHash = {};

    for( let i = 0; i < a.length; i++ ) {
      const ai = a[i];
      const s = config.selectNodes(ai[0]);
      for( let j = 0; j < s.length; j++ ) {
        const c = s[j];
        const res = ai[1](c);
        if( !resourceHash[res] ) {
          resources.push([res, c.getAttribute("dependencies") === "true"]);
          resourceHash[res] = true;
        }
      }
    }

    if( boot.depend && boot.depend.js ) {
      for( let i=0; i<boot.depend.js.length; i++) {
        resources.push( [ boot.depend.js, false ] );
      }
    }
  }

  function conf_success(xhr) {
    const d = xhr.responseXML.documentElement;
    d.selectNodes = function(x) {
      const f = [];
      let n = null;
      try {
        const r = xhr.responseXML.evaluate(x, this, null, 0, null);
        while (n = r.iterateNext()) {
          f.push(n);
        }
      } catch ( e ) {
        alert(e);
      }
      return f;
    };

    const files = d.selectNodes("styles/include[@href]");
    for(let i=0; i<files.length; i++) {
      loadCSS(files[i].getAttribute("href"));
    }
    selectResources(d);
    loadResources();
  }

  function finished() {
    resources = 0;
    console.timeEnd("Loading XIOS");
    console.time("Initializing XIOS");
    Utils_applyIEEmulation(top);
    Utils_applyIEEmulation(boot.win);

    while( listeners.length ) {
      const listener = listeners.pop();
      listener[0].removeEventListener(listener[1], listener[2]);
    }
    listeners = 0;

    for( let i=0; i<boot.beforeInit.length; i++ ) {
      boot.beforeInit[i]();
    }
    boot.beforeInit = { push : function() {
      for( let i=0; i<arguments.length; i++ ) {
        try {
          arguments[i]();
        } catch(e) {
          console.log(e);
        }
      }
      return arguments.length;
    } };

    if( boot.doTrace && _el("debugTools") ) {
      _el("debugTools").style.display = "";
    }
    sys.init().then(function() {
      console.timeEnd("Initializing XIOS");
      sys.open( boot.startup );
    });
  }

  console.time("Loading XIOS");
  function lowLoad() {
    if( document.readyState==="loading" ) {
      addListener(document, "DOMContentLoaded", lowLoad, { once : true });
      return;
    }

    initContainers();

    if( boot.developer ) {
      HttpRequest_request(boot.system, {}, false, null,
                          conf_success, conf_failure);
      return;
    }

    loadCSS("/xios/style.css");
    function promiseJS(href) {
      return new Promise(function(resolve) {
        loadJS(href, resolve);
      });
    }
    promiseJS("/xios/system.js").then(function() {
      const loading = [];
      if( boot.depend && boot.depend.js ) {
        for( let i=0; i<boot.depend.js.length; i++ ) {
          loading.push( promiseJS(boot.depend.js[i]) );
        }
      }
      Promise.all(loading).then(finished);
    });
  }

  initEnv();
  if( boot.isIE ) {
    window.onhelp = function() { return false; };
    loadJS("xios/external/promise.min.js", function() {
      loadJS("xios/external/wgxpath.install.js", function() {
        wgxpath.install();
        lowLoad();
      })
    });
  }
  else {
    lowLoad();
  }
}();

function HttpRequest_request(uri, options, useSync, credentials,
                             success, failure, begin, end) {
  options = options || {};
  function getBool(name, def) {
    if( options[name]===true ) {
      return true;
    }
    if( options[name]===false ) {
      return false;
    }
    return def;
  }

  let xhr;
  if( top.reqtrace ) {
    top.reqtrace("HttpRequest_request uri: " + uri);
  }
  const async = useSync ? false : getBool("async", true);
  const method = options.method || "GET";
  const headers = options.headers;
  const body = options.body || null;
  const responseType = options.responseType;
  let timeout = options.timeout || boot.HTTPTimeout;
  if( navigator.onLine===false ) {
    // When offline we can still access localhost if present. Set an
    // aggressive timeout.
    timeout = 100;
  }
  let attempts = options.attempts;
  if( !attempts ) {
    if( method==="GET" ) {
      attempts = 2;
    } else {
      attempts = 1;
    }
  }
  const activityIcon = window.sys && window.sys.activityIcon;

  if( responseType && !async ) {
    failure( { statusText : "Can't load synchronously with responseType." } );
    return;
  }

  function handleResponse() {
    const ok = xhr && (xhr.status >= 200 && xhr.status < 300);
    if( !ok && credentials && attempts > 0 ) {
      let p = credentials.handleError(xhr);
      if(p) {
        p.addCallback(startRequest, handleRequest);
        return;
      }
    }

    if( end ) {
      end();
    }
    if( ok ) {
      if( boot.isIE && responseType==="json" ) {
        try {
          const x2 = {};
          for(let i in xhr) {
            x2[i] = xhr[i];
          }
          x2.response = JSON.parse(xhr.responseText);
          xhr = x2;
        } catch(e) {
          failure(xhr);
        }
        success(xhr);
      }

      if( success ) {
        success(xhr);
      }
    } else {
      if( failure ) {
        failure(xhr);
      }
    }
    if( activityIcon ) {
      activityIcon.stopLoading(uri);
    }
  }

  function startRequest() {
    // Are we out of attempts?
    if( attempts-- <= 0 ) {
      handleResponse();
      return;
    }

    // Clean up old XHR and create a new one.
    if( xhr ) {
      try {
        xhr.abort();
      } catch(e) {}
    }
    xhr = new XMLHttpRequest();
    if( responseType && !(boot.isIE && responseType==="json") ) {
      // IE doesn't handle JSON responseType.
      xhr.responseType = responseType;
    }

    if( credentials ) {
      credentials.openXHR(xhr, method, uri, async).addBoth(runRequest);
    } else {
      xhr.open(method, uri, async);
      runRequest();
    }

    function runRequest() {
      if( async ) {
        xhr.addEventListener("readystatechange", readyStateChanged);
        if( timeout ) {
          xhr.timeout = timeout;
          xhr.ontimeout = startRequest;
        }
      }

      if( headers ) {
        for( let key in headers ) {
          xhr.setRequestHeader(key, headers[key]);
        }
      }
      try {
        xhr.send(body);
      } catch(e) {
        handleResponse();
        return;
      }
      if( !async ) {
        handleResponse();
      }
    }
  }

  function readyStateChanged() {
    if( xhr.readyState === XMLHttpRequest.DONE ) {
      xhr.removeEventListener("readystatechange", readyStateChanged);
      handleResponse();
      xhr = null;
    }
  }

  if( activityIcon ) {
    activityIcon.startLoading(uri);
  }
  if( begin ) {
    begin();
  }
  startRequest();
}

function HttpRequest_getXmlDocument(href) {
  if( top.reqtrace ) {
    top.reqtrace("HttpRequest_getXmlDocument href: " + href);
  }
  if( !href ) {
    const doc = top.xml.createXMLDocument();
    doc.async = false;
    return doc;
  }

  const xhr = new XMLHttpRequest();
  xhr.open("GET", href, false);
  xhr.send(null);
  return xhr.responseXML;
}
