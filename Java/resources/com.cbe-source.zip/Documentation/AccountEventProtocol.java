package com.cbe;
/**  
 * Protocol for implementing a AccountDelegate.<br>
 * Abstract base class which is used when you want notification on<br>
 * changes related to account status. Note this class needs to be implemented by the user. <br>
 * @author CloudBackend
 * @version 1.4.6
 */
public class AccountEventProtocol {

  /**
   *  Gets called when the account status has changed (required). 
   */
  public void onLogin(long atState, CloudBackend cloudbackend) {}

  /**
   *  Gets called when the account status has changed (required). 
   */
  public void onLogout(long atState) {}

  /**
   *  Gets called when the account status has changed (required). 
   */
  public void onCreated(long atState) {}

  /**
   *  Gets called when the account status has changed (required). 
   */
  public void onError(long failedAtState, long code, String reason, String message) {}

  /**
   * AccountEventProtocol Constructor.
  */
  public AccountEventProtocol() {}

}
