package com.cbe;

/**
 * class Container child class of Item and API:s towards server/edge node with create, move and data management e.t.c. <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class Container extends Item {

  /**
   * Create's a container Inside this containerto be used for adding objects.<br>
   * @param name for the container.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public Container create(String name, ItemEventProtocol delegate) {}

  /**
   * Move is used to move container whith its content to user specified location ex other container or to root container.<br>
   * @param destinationId: id of the container to which it should be moved to.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public void move(long destinationId, ItemEventProtocol delegate) {}

  /**
   * Rename the container.<br>
   * @param name (new name).<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public void rename(String name, ItemEventProtocol delegate) {}

  /**
   * Removes/deletes the container and all its content.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public void remove(ItemEventProtocol delegate) {}

  /**
   * Creates an object with indexed tags or indexed tags + non indexed tags.<br>
   * @param name        Name of the object.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   * @param metadata    (Optional) Metadata is a map with the tag (key), the value of that tag and if it is indexed or not
   */
  public Object createObject(String name, ItemEventProtocol delegate, Obj_KV_Map metadata) {}

  /**
   * Creates an object with indexed tags or indexed tags + non indexed tags.<br>
   * @param name        Name of the object.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   * 
   */
  public Object createObject(String name, ItemEventProtocol delegate) {}

  /**
   * Upload object to container with path, the object is instantly returned with a temp. id. Once the respons from the server is called back the object gets updated with the correct unique object id:<br>
   * @param name.<br>
   * @param path.<br>
   * @param delegate, TransferDelegate is a callback delegate to the user defined/implementation of the callbacks on TransferUploadEventProtocol. <br>
   */
  public Object upload(String name, String path, TransferUploadEventProtocol delegate) {}

  /**
   * Upload object to container with binary data:<br>
   * @param name.<br>
   * @param data byte array of the object.<br>
   * <br>
   * @param delegate, TransferDelegate is a callback delegate to the user defined/implementation of the callbacks on TransferUploadEventProtocol. <br>
   */
  public Object uploadBinary(String name, byte[] data, TransferUploadEventProtocol delegate) {}

  /**
   * Call to get a list of items in the container. Implement onQueryLoaded to from CBE::ItemDelegatePtrto recieve the callback.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>       
   */
  public QueryChain query(ItemEventProtocol delegate) {}

  /**
   * Call to get a list of items in the contianer. Implement onQueryLoaded to from CBE::ItemDelegatePtrto recieve the callback.<br>
   * @param filter<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>       
   */
  public QueryChain query(Filter filter, ItemEventProtocol delegate) {}

  /**
   * Queries the container with a given relative path, returns container with objects. ex: /Documents/Pictures will return objects and subContainers for Documents and Pictures.<br>
   * <br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public QueryChain queryWithPath(String relativePath, ItemEventProtocol delegate) {}

  /**
   * Search the whole container for tags related to Objects in the container structure. <br>
   * EX: Key = Name, Value Contract/Object/Song =&gt; Name:Contract1.<br>
   * <br>
   * Search handles tags in combination of conjunctions of keys and/or key values seperated by |.<br>
   * EX: Name:*|Country:Sweden|Country:Norway, this would search for objects with key Name but any value and where key Country is either Sweden or Norway.<br>
   * @param tags is a string of key tags or key:value pairs that are seperated by |.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public QueryResult search(String tags, ItemEventProtocol delegate) {}

  /**
   * Search the whole container for tags related to Objects in the container structure. <br>
   * EX: Key = Name, Value Contract/Object/Song =&gt; Name:Contract1.<br>
   * <br>
   * Search handles tags in combination / conjunction of keys and/or key values seperated by |.<br>
   * EX: Name:*|Country:Sweden|Country:Norway, this would search for objects with key Name but any value and where key Country is either Sweden or Norway.<br>
   * @param filter is a CBE::Filter on which you can set how you want data to be ordered when searching, remember to set the queryString to be keys/tags or key:value pairs that are seperated by |.<br>
   * @param delegate, ItemDelegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public QueryResult search(Filter filter, ItemEventProtocol delegate) {}

  /**
   * set the Access control list for the container. For containers set does set the whole container tree, so all its' sub items as well. Remeber this is set and not update so everytime you set all ids' that should be there should be added.<br>
   * @param toUserPermissions is a std::map of uint64_t and signed int (userId and permission), simply setting the permission you want to a valid user id that you want. CBE::permission_status_t is defined in Types.h.<br>
   * @param delegate, shareDelegate is a callback delegate to the user defined/implementation of the callbacks on ShareEventProtocol. <br> 
   */
  public void setACL(ACL_Map toUserPermissions, ShareEventProtocol delegate) {}

  /**
   * get the Access Control List for the Container.<br>
   * @param delegate, shareDelegate is a callback delegate to the user defined/implementation of the callbacks on ShareEventProtocol. <br>
   */
  public void getACL(ShareEventProtocol delegate) {}

  /**
   * Shares a container and its content to a user.  This provides the user the ability to access what has been shared to them via the listAvailableShares command.  To allow users to view and change shared information see ACLs. <br>
   * Note: At present Shareing the container gives the user read permissions for the container and all its sub-items, this might change in the future.<br>
   * @param toUserGroup takes a user id or group id to share to.<br>
   * @param description names the specific share between you and the user/group.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ShareEventProtocol. <br> 
   */
  public void share(long toUserGroup, String description, ShareEventProtocol delegate) {}

  /**
   * unShare the container to a specific shareId created when sharing. Each share is unique between user/group and the one sharing. This is represented with a unique share id.<br>
   * @param shareId is as mentioned the unique id for a share between the owner and other user/group.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ShareEventProtocol. <br>
   */
  public void unShare(long shareId, ShareEventProtocol delegate) {}

}
