package com.cbe;

/**
 * Protocol for implementing a delegate.<br>
 * Abstract base class which is used when you want notification about
 * events from group calls. <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class GroupEventProtocol {

  public void onGroupSearchLoaded(long newPersistenceState, GroupQuery queryResult) {}

  /**
   * Gets called when a group has been created.
   */
  public void onGroupAdded(long newPersistenceState, Group group) {}

  /**
   * Lists the groups that the user is included in or owner/admin of.
   */
  public void onListGroups(Groups_Vec groups) {}

  /**
   * Gets called when a group has been removed.
   */
  public void onGroupRemoved(long newPersistenceState) {}

  /**
   * Gets called when the user leaves a group.
   */
  public void onMemberLeaveGroup(long newPersistenceState) {}

  /**
   * Gets called when a user have become a member of a group.
   */
  public void onMemberJoinGroup(long newPersistenceState) {}

  /**
   * Gets called when a member has been kicked.
   */
  public void onMemberKicked(long newPersistenceState) {}

  /**
   * Gets called when a member has been banned.
   */
  public void onMemberBanned(long newPersistenceState) {}

  /**
   * Gets called when a member has been unbanned.
   */
  public void onMemberUnBanned(long newPersistenceState) {}

  /**
   * Gets called when listBannedMembers has been called.
   */
  public void onListBannedMembers(Members_Vec members) {}

  /**
   * Gets called when a list call of members of a group have happened.
   */
  public void onListMembers(long newPersistenceState, Members_Vec members) {}

  /**
   * Gets called when a group have been renamed.
   */
  public void onGroupRenamed(long newPersistenceState) {}

  /**
   * Gets called when an error have occured.
   */
  public void onGroupError(long operationId, long operation, long failedAtState, long code, String reason, String message) {}

  /**
   * GroupEventProtocol Constructor.
   */
  public GroupEventProtocol() {}

}
