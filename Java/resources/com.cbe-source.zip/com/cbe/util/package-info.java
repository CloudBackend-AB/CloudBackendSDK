    /**
     * The CloudBackend utility package for the SDK.
     * 
     * <p>
     * <b>Use:</b>
     * For synchronous non throwing calls
     * to return additional and extended error information context.
     * </p>
     * @since 2.1
     */
    package com.cbe.util;
