package com.cbe;
/**
 * class Stream, functions for Stream information. <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class Stream {

  /**
   * set Stream id.
   * @param value long streamId. 
   */
  public void set_streamId(long value) {}

  /**
   *  Stream id retrived from the server / edge node. 
   */
  public long get_streamId() {}

  /**
   * set length/size of the binary data of the stream.
   * @param value long length of binary data. <br> 
   */
  public void set_length(long value) {}

  /**
   * get length/size of the binary data of the stream. 
   */
  public long get_length() {}

}
