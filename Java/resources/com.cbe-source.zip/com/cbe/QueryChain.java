package com.cbe;

/**
 * Class QueryChain. API call to query returns a QueryChain object that can call join on a query. 
 * ex: QueryChain qChain = container.query(itemDelegate).join(otherContainer, key1, key2, filter, container); <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class QueryChain {

  /**
   * Performs a join requet in conjunction with a query to get related items from another container.  If chained with a query or other joins the delegate will be called once with the complete joined query result.<br>
   * @param containerToQuery: The container the join should be done with.<br>
   * @param key1: The key from the previous query on which to perform the join.<br>
   * @param key2: The key on objects in containerToQuery on which to perform the join<br>
   * @param delegate: If this is null and join is chained with query the delegate from the query will be used.  If join is called on a querychain where a query has completed a delegate should be passed in to the final join in the chain.  
   */
  public QueryChain join(Container containerToQuery, String key1, String key2, ItemEventProtocol delegate) {}

  /**
   * Performs a join requet in conjunction with a query to get related items from another container.  If chained with a query or other joins the delegate will be called once with the complete joined query result.<br>
   * @param containerToQuery: The container the join should be done with.<br>
   * @param key1: The key from the previous query on which to perform the join.<br>
   * @param key2: The key on objects in containerToQuery on which to perform the join<br>
   * 
   */
  public QueryChain join(Container containerToQuery, String key1, String key2) {}

  /**
   * Performs a join requet in conjunction with a query to get related items from another container<br>
   * with additional constraints.  If chained with a query or other joins the delegate will be called<br>
   * once with the complete joined query result.<br>
   * @param containerToQuery: The container the join should be done with.<br>
   * @param key1: The key from the previous query on which to perform the join.<br>
   * @param key2: The key on objects in containerToQuery on which to perform the join<br>
   * @param constraints: A filter that provides any constraints for the query.<br>
   * @param delegate: If this is null and join is chained with query the delegate from the query will<br>
   * be used.  If join is called on a querychain where a query has completed a delegate should be passed<br>
   * in to the final join in the chain.<br>
   * \  
   */
  public QueryChain join(Container containerToQuery, String key1, String key2, Filter constraints, ItemEventProtocol delegate) {}

  /**
   * Performs a join requet in conjunction with a query to get related items from another container<br>
   * with additional constraints.  If chained with a query or other joins the delegate will be called<br>
   * once with the complete joined query result.<br>
   * @param containerToQuery: The container the join should be done with.<br>
   * @param key1: The key from the previous query on which to perform the join.<br>
   * @param key2: The key on objects in containerToQuery on which to perform the join<br>
   * @param constraints: A filter that provides any constraints for the query.<br>
   * 
   */
  public QueryChain join(Container containerToQuery, String key1, String key2, Filter constraints) {}

  /**
   * Performs a join requet in conjunction with a query using items in another container to adjust<br>
   * results. If chained with a query or other joins the delegate will be called once with the<br>
   * complete joined query result.<br>
   * @param containerToQuery: The container the join should be done with.<br>
   * @param key1: The key from the previous query on which to perform the join.<br>
   * @param key2: The key on objects in containerToQuery on which to perform the join<br>
   * @param containerForResults: Can be the conainer from the previous query if desired items should<br>
   * be from that container.<br>
   * @param delegate: If this is null and join is chained with query the delegate from the query will<br>
   * be used.  If join is called on a querychain where a query has completed a delegate should be<br>
   * passed in to the final join in the chain.
   */
  public QueryChain join(Container containerToQuery, String key1, String key2, Container containerForResults, ItemEventProtocol delegate) {}

  /**
   * Performs a join requet in conjunction with a query using items in another container to adjust<br>
   * results. If chained with a query or other joins the delegate will be called once with the<br>
   * complete joined query result.<br>
   * @param containerToQuery: The container the join should be done with.<br>
   * @param key1: The key from the previous query on which to perform the join.<br>
   * @param key2: The key on objects in containerToQuery on which to perform the join<br>
   * @param containerForResults: Can be the conainer from the previous query if desired items should<br>
   * be from that container.<br>
   * 
   */
  public QueryChain join(Container containerToQuery, String key1, String key2, Container containerForResults) {}

  /**
   * Performs a join requet in conjunction with a query to adjust resluts with additional constraints<br>
   * on the joined container.If chained with a query or other joins the delegate will be called once<br>
   * with the complete joined query result.<br>
   * @param containerToQuery: The container the join should be done with.<br>
   * @param key1: The key from the previous query on which to perform the join.<br>
   * @param key2: The key on objects in containerToQuery on which to perform the join<br>
   * @param constraints: A filter that provides any constraints for the query.<br>
   * @param containerForResults: Can be the conainer from the previous query if desired items should<br>
   * be from that container.<br>
   * @param delegate: If this is null and join is chained with query the delegate from the query will<br>
   * be used.  If join is called on a querychain where a query has completed a delegate should be<br>
   * passed in to the final join in the chain.
   */
  public QueryChain join(Container containerToQuery, String key1, String key2, Filter constraints, Container containerForResults, ItemEventProtocol delegate) {}

  /**
   * Performs a join requet in conjunction with a query to adjust resluts with additional constraints<br>
   * on the joined container.If chained with a query or other joins the delegate will be called once<br>
   * with the complete joined query result.<br>
   * @param containerToQuery: The container the join should be done with.<br>
   * @param key1: The key from the previous query on which to perform the join.<br>
   * @param key2: The key on objects in containerToQuery on which to perform the join<br>
   * @param constraints: A filter that provides any constraints for the query.<br>
   * @param containerForResults: Can be the conainer from the previous query if desired items should<br>
   * be from that container.<br>
   * 
   */
  public QueryChain join(Container containerToQuery, String key1, String key2, Filter constraints, Container containerForResults) {}

  /** Returns the QueryResult from the join. */
  public QueryResult getQueryResult() {}

}
