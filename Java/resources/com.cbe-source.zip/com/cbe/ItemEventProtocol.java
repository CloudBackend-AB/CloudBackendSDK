

package com.cbe;
/**
 * Protocol for implementing a item delegate.<br>
 * Abstract base class which is used when you want notification on
 * changes related to Containers and Objects. Note this class needs to be implemented by the user. <br> 
 * @author CloudBackend <br>
 * @version 1.4.6 <br>
 */
public class ItemEventProtocol {

  /**
   *  Gets called when a Object has been added. 
   */
  public void onObjectAdded(Object object) {}

  /**
   *  Gets called when Metadata has been saved/Added. 
   */
  public void onMetadataAdded(Object object) {}

  /**
   *  Gets called when a Object has been moved. 
   */
  public void onObjectMoved(Object object) {}

  /**
   *  Gets called when a Object has been removed. 
   */
  public void onObjectRemoved(long objectId, String name) {}

  /**
   *  Gets called when a Object has been renamed. 
   */
  public void onObjectRenamed(Object object) {}

  /**
   *  Gets called when a Object has been Updated. 
   */
  public void onObjectUpdated(Object object) {}

  /**
   *  Gets called when a Object has been Updated. 
   */
  public void onStreamsLoaded(Object object) {}

  /**
   *  Gets called when a Container has been added. 
   */
  public void onContainerAdded(Container container) {}

  /**
   *  Gets called when a Container has been moved. 
   */
  public void onContainerMoved(Container container) {}

  /**
   *  Gets called when a Container has been removed. 
   */
  public void onContainerRemoved(long containerId, String name) {}

  /**
   *  Gets called when a Container has been renamed. 
   */
  public void onContainerRenamed(Container container) {}

  /**
   *  Gets called when a Container has been restored. 
   */
  public void onContainerRestored(Container container) {}

  /**
   *  Gets called when a Query has been loaded either from cache or edge / cloud 
   */
  public void onQueryLoaded(QueryResult dir) {}

  /**
   *  If a query fail e.g a filter requesting a container or object that does not exists, a loadError will happen.<br>
   * "In the future when there will be micro clouds with edge nodes including central clouds you will be able to ask for containers and objects <br>
   * from different peering points in the hierarchy and might then fail if the object or container is not loacated in that point (due to settings in where you want data replicated).
   */
  public void onLoadError(Filter filter, long operation, long code, String reason, String message) {}

  /**
   *  Gets called when an join error has happened, ex: Bad Request in form of key word searching for table does not exist. 
   */
  public void onJoinError(long operation, long code, String reason, String message) {}

  /**
   *  Gets called when an error regarding an item occurred. e.g create rename, move, remove 
   */
  public void onItemError(Item container, int type, long operation, long failedAtState, long code, String reason, String message) {}

  public ItemEventProtocol() {}

}
