function getParam(param) {
  if( !getParam.params ) {
    if( !window.locationSearch ) {
      window.locationSearch = location.search;
    }
    var q = window.locationSearch;
    q = q.slice(1).split("&");
    var params = {};
    for( var i = 0; i < q.length; i++ ) {
      var kv = q[i].split("=");
      params[kv[0]] = kv[1];
    }
    getParam.params = params;
  }
  return getParam.params[param];
}
function dom() {
  var v = getParam("dom");
  if( v !== "undefined" && v !== undefined ) {
    document.domain = unescape(v);
  }
}
function cb() {
  var v = getParam("cb");
  if( v ) {
    if( getParam("w") === "1" ) {
      return opener.top[unescape(v)];
    }
    return top[unescape(v)];
  }
  return function(){};
}
function id() {
  var v = getParam("fid");
  if( v ) {
    return unescape(v);
  }
  return -1;
}
dom();
