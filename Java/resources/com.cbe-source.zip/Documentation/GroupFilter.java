package com.cbe;

/**
 * class GroupFilter, helper class for GroupQueries see API:s on groupManager. <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class GroupFilter {

  /**
   *  Returns the query string that was set on the filter. I.E key:value (name:*) would be an example. 
   */
  public String getQuery() {}

  public String getFilter() {}

  /**
   *  Returns the settings on how the data was sorted and displayed. 
   */
  public boolean getAscending() {}

  public boolean getDeleted() {}

  public boolean getPublicFirst() {}

  /**
   *  Returns the offset that was used for the filter in the query. 
   */
  public long getOffset() {}

  /**
   *  Returns the value of the count that was set for the query.
   */
  public long getCount() {}

  /**
   * get the filterorder as a string.
   */
  public String getOrder() {}

  /**
   *  Returns the order the query was sorted check enum FilterOrder to see options for sorting. 
   */
  public FilterOrder getGroupOrder() {}

  /**
   *  Set the query string, e.x: Name:* (would search for all objects with the metadata key of Name). <br>
   * Note* if used with rootContainer id as the dataId to search in the whole account will be searched. 
   */
  public void setQuery(String arg0) {}

  /**
   * Not fully tested but should be a regular expression.
   */
  public void setFilter(String arg0) {}

  /**
   *  Sets the Order in which data should be displayed: Acending meaning alfabetical  
   */
  public void setAscending(boolean arg0) {}

  /**
   * If you want to see deleted groups set deleted to true.
   */
  public void setDeleted(boolean arg0) {}

  /**
   *  Set the offset for paging, offset is the item offset where to start your query. i.e:<br>
   *  There is already a query of the first 99 items and to get the rest you've setOffest to 100 to get the next set.
   */
  public void setOffset(long arg0) {}

  /**
   *  Set the Number of items you want to get from a container. <br>
   * So if a container has 50 items but you only want the 10 first in ascending order then set ascending to true and setCount to 10. 
   */
  public void setCount(long arg0) {}

  /**
   *  Set the order of how data will be shown by the enum of FilterOrder ex: Titel first, published e.t.c 
   */
  public void setGroupOrder(FilterOrder o) {}

  public boolean matchesGroupId(long id) {}

  public boolean matchesQuery(long parentId, int type, boolean isDeleted) {}

  public boolean matchesQuery(Group group) {}

  public boolean equals(GroupFilter filter) {}

  public void updateCompareValue() {}

  public String order() {}

  public void order(String o) {}

  public GroupFilter() {}

}
