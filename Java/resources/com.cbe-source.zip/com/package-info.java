    /**
     * Contains the CloudBackend SDK for Java.
     * 
     * <h3>
     * Software Development Kit
     * </h3>
     * <p>
     * <img src="https://cloudbackend.com/assets/img/pin.png" alt="pin" align="center" height="100">
     * SDK for Java,
     * with the Asynchronous API
     * for the CloudBackend Singularity database service.
     * </p>
     * <h3>
     * Asynchronous API
     * </h3>
     * <p>
     * Working asynchronously means that the main thread may continue to work
     * while there is a separate parallel thread delegate created that will wait
     * for the response, process the response,
     * and optionally make any follow up processing or hand over.
     * This means that the applications you write on top of the SDK will be
     * event-driven instead of being triggered by a main loop.
     * The end user experience will be a user interface that is responsive
     * and does not freese while waiting for a server response.
     * Working this way guarantees everything presented to the end user has been
     * propagated to the Singularity Database and will be what is retrieved
     * if another client communicates with the database.
     * </p>
     * <img src="https://cloudbackend.com/assets/img/SDK.png" alt="SDK" width="90%">
     * <h3>
     * login()
     * </h3>
     * <p>
     * User can log in by calling login() submitting parameters with the credentials of:
     * <ul>
     *   <li>username</li>
     *   <li>password</li>
     *   <li>tenant</li>
     *   <li>client</li>
     * </ul>
     * Create a Delegate that will get an input-callback of either:
     * <ul>
     *   <li>success</li>
     *   <li>error</li>
     * </ul>
     * Call the logIn() with credentials and the pointer to the delegate that
     * is going to handle the callback.
     * Normally you need to wait for the completion and then,
     * depending on if the result was success or error, take an appropriate action. 
     * </p>
     * <h3>
     * Examples
     * </h3>
     * <p>
     * See the Example code included in the SDK package,
     * <a href="https://cloudbackend.com/developer.html#how" target="_blank">how to</a>.
     * </p>
     * <h3>
     * Tutorial
     * </h3>
     * <p>
     * See the overview and the tutorial in the dashboard
     * <a href="https://db.cloudbackend.com/docs.html?doc=dashboard/help/sdk.xml" target="_blank">documentation</a>
     * </p>
     * <h4>
     * Accnowledgement
     * </h4>
     * <p>
     * Java is a registered trademark of Oracle.
     * </p>
     * @since 1.3
     */
    package com;
