
function Button_init(id, config) {
  function btnHover(e) {
    if( !disabled ) {
      this.className = "htmlbtn_hover";
    }
  }

  function btnDown(e) {
    if( !disabled ) {
      this.className = "htmlbtn_down";
    }
  }

  function btnOut(e) {
    if( !disabled ) {
      this.className = "htmlbtn";
    }
  }
  function click(e) {
    if( !disabled ) {
      clickAction.apply(b, [e]);
    }
  }
  function handle(f) {
    return function(e) {
      f.apply(b, [e]);
    }
  }

  var disabled = config.disabled;
  var clickAction = config.click;

  var b = document.getElementById(id);
  b.setDisabled = function(d) {
    disabled = typeof d == "undefined" ? true : d;
    if( disabled ) {
      b.className = "htmlbtn htmlbtn_disabled";
    } else {
      b.className = "htmlbtn";
    }
  }
  if( disabled ) {
    b.setDisabled();
  }
  if( b.addEventListener ) {
    b.addEventListener("mouseover", handle(btnHover), false);
    b.addEventListener("mousedown", handle(btnDown), false);
    b.addEventListener("mouseout", handle(btnOut), false);
    b.addEventListener("mouseup", handle(btnOut), false);
    b.addEventListener("click", handle(click), false);
  } else {
    b.attachEvent("onmouseover", handle(btnHover));
    b.attachEvent("onmousedown", handle(btnDown));
    b.attachEvent("onmouseout", handle(btnOut));
    b.attachEvent("onmouseup", handle(btnOut));
    b.attachEvent("onclick", handle(click));
  }
}
