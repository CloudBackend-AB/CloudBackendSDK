package com.cbe;

/** 
 * Protocol for implementing a share delegate.<br>
 * Abstract base class which is used when you want notification on
 * changes related to share calls. Note this class needs to be implemented by the user. <br> 
 * @author CloudBackend. <br>
 * @version 1.4.6 <br>
 */
public class ShareEventProtocol {

  /**
   *  Gets called when a query for available shares that have been shared to you. 
   */
  public void onListAvailableShares(QueryResult result) {}

  /**
   *  Gets called when a query for shares that you have shared to other accounts or groups. 
   */
  public void onListMyShares(QueryResult qResult) {}

  /**
   *  Gets called when an Access Control List (std::map with user_id and permission) has been added to a Container 
   */
  public void onContainerACLAdded(ACL_Map ACLs) {}

  /**
   *  Gets called when an Access Control List (std::map with user_id and permission) has been added to an Object 
   */
  public void onObjectACLAdded(ACL_Map ACLs) {}

  /**
   *  Gets called when an Access Control List (std::map with user_id and permission) has been loaded for a Container 
   */
  public void onContainerAclLoaded(UserId_Vec userIds, ACL_Map ACLMap) {}

  /**
   *  Gets called when an Access Control List (std::map with user_id and permission) has been loaded for an Object 
   */
  public void onObjectAclLoaded(UserId_Vec userIds, ACL_Map ACLMap) {}

  /**
   *  Gets called when a Container has been shared<br>
   * @param shareId is the id of the share and is needed when unSharing and can be used to locate which user is tied to that share. 
   */
  public void onContainerShared(long shareId) {}

  /**
   *  Gets called when a Container has been unShared, message will be OK else an shareError will be thrown.  
   */
  public void onContainerUnShared(String message) {}

  /**
   *  Gets called when an Object has been shared. 
   */
  public void onObjectShared(long shareId) {}

  /**
   *  Gets called when an Object has been unshared, massage will be OK, if not ok there will be a shareError thrown. 
   */
  public void onObjectUnShared(String message) {}

  /**
   *  Errors regarding share and list share calls onShareError. 
   */
  public void onShareError(int type, long operation, long code, String reason, String message) {}

  /**
   *  Gets called when errors regarding ACLs have occured, outcome of a get or setACL that has failed.<br>
   * @param type is either Container or Object.<br>
   * @param operation is set or getACL for either Container or Object.<br>
   * @param code is according to w3 standards, for more information look at cloudbackend website or look at RFC 7231<br>
   * @param reason is from server/edge why the error occured.<br>
   * @param message of the error can be something like 403, forbidden, permission denied where permission denied is the message <br>
   * telling you that the ACL:s you've set is not allowing the other user to access the Object or Container. 
   */
  public void onACLError(int type, long operation, long code, String reason, String message) {}

  public ShareEventProtocol() {}

}
