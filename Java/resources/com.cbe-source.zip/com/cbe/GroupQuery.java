package com.cbe;

/**
 * class GroupQuery, class that manages return group queries. <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class GroupQuery {

  public GroupQuery() {}

  /**
   *  Returns a copy of the filter used for query.
   */
  public GroupFilter filter() {}

  /**
   * Returns a copy of a vector containing the groups for the queryResult.    <br>
   * The queryResult will update when new data comes in but the copy will not.<br>
   * If iterating make sure to create a variable for a local copy.<br>
   * @return vector&lt;CBE::GroupPtr&gt; contains the groups matching the query.
   */
  public Groups_Vec getGroupsSnapshot() {}

  /**
   *  groups loaded in the queryResult.
   */
  public long GroupsLoaded() {}

  /**
   *  total Groups in the cloud matching the query result.  This may be more than loaded.
   */
  public long totalCount() {}

  /**
   *  Returns if the group with groupId was loaded in the query. 
   */
  public boolean containsGroup(long groupId) {}

}
