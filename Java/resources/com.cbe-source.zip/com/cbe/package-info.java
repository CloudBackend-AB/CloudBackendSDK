    /**
     * The core CloudBackend package for the Java SDK.
     * 
     * <p>
     * For more information see also the  
     * <a href="https://cloudbackend.com/developer.html">CloudBackend web site</a>.
     * </p>
     * @since 2.0
     */
    package com.cbe;
