var langDoc = [];
var labelNodes = {};

/**
* Localizes current html document.
*
* @param String localeDir
*  Path to the directory where the language files are found
*
* @param Boolean force
*  When set to true the locale is allways applied
*
* @param String locale
*  If set, use this locale instead of cookie value
*/
function localize(localeDir, force, locale) {

  var language;
  if (locale && locale != "undefined" && locale != "" ) {
    language = locale;
  } else {
    language = getCookie("xiosLanguage");
  }

  if( (language && (language != "en_US" || force)) ) {
    loadLanguageFile(localeDir, language, applyLocale);
  }
}

/**
* Applies a loaded language file to current html document.
* Note: The language file must be loaded when this function is called
*/
function applyLocale() {
  var res = $("*[loc='true']");
  var len = res.length;
  for( let i = 0; i < len; i++ ) {
    var jQueryObj = res[i];
    var attributes = jQueryObj.attributes;
    var attrLen = attributes.length;
    for( let j = 0; j < attrLen; j++ ) {
      let attribute = attributes[j];
      var name = attribute.name;
      if( name != "loc" && name.indexOf("loc") == 0 ) {
        var newLabel = getLabel(attribute.nodeValue);
        if( newLabel ) {
          if( name == "loctext" ) {
            if( boot.isIE ) {
              jQueryObj.innerText = newLabel;
            } else {
              jQueryObj.innerHTML = newLabel;
            }
            jQueryObj.title = newLabel;
          } else {
            var tokens = name.split("_");
            if( tokens && tokens[1] ) {
              jQueryObj.setAttribute(tokens[1], newLabel)
            }
          }
        }
      }
    }
  }
}

/**
* Loads a language file
*
* @param localeDir
*  Path to the directory where the language files are found
*
* @param String locale
*  Locale that should be loaded
*
* @param Function callback
*  Function that is called when the language file is loaded
*/
function loadLanguageFile(localeDir, locale, callback) {
  $.ajax({
    type: "GET",
    url: localeDir + "/" + locale + ".xml",
    success: completed,
    error: failed
  });
  function failed() {
    if( locale != "en_US" ) {
      loadLanguageFile(localeDir, "en_US", callback);
    }
  }
  function completed(res) {
    var doc = res;
    if( !boot.isIE ) {
      doc.selectNodes = function nds(x) {
        var xr = new XPathEvaluator(), nr = xr.createNSResolver(this), f = [], n = null;
        try {
          var r = xr.evaluate(x, this, nr, 0, null);
          while (n = r.iterateNext()) {
            f.push(n);
          }
        } catch ( e ) {
          alert(e);
        }
        return f;
      };
      doc.selectSingleNode = function nd(x) {
        return doc.selectNodes(x)[0];
      }
    }
    langDoc.push(doc);
    callback();
  }
}

/**
* Returns a localized label found in the loaded language file.
*
* @param String labelId
*  Id of the label
*
* @param Object params
*  Parameter to be used to build the string
*/
function getLabel(labelId, params) {
  function find() {
    for( var i = 0, len = langDoc.length; i < len; i++ ) {
      labelNode = langDoc[i].selectSingleNode("/keys/key[@id = '" + labelId + "']");
      if( labelNode ) return labelNode;
    }
  }

  var labelNode = labelNodes[labelId];
  if( !labelNode ) {
    labelNode = find();
    if( !labelNode ) return null;
    labelNodes[labelId] = labelNode;
  }
  var text = labelNode.text || labelNode.textContent;
  if( params ) {
    for( const x in params ) {
      var re = new RegExp("{\\$" + x + "}", "g");
      text = text.replace(re, params[x]);
    }
  }
  return text;
}

//######### end localize functions #################

/**
* Sets a browser cookie
*
* @param String key
*  The key that the cookie should be stored and associated with
*
* @param String value
*  Value to store in cookie
*/
function setCookie(key, value) {
  document.cookie = key + "=" + value + ";expires=Fri, 31 Dec 2099 23:59:59 GMT;path=/";
}

/**
* Retrievs parameters from a href and puts them in an Object
*
* @param String paramsStr
*  Href that might contain parameters
*
* @return Object
*  Object with each parameter as a key->value pair
*/
function getUrlParams(paramsStr) {
  if( !paramsStr ) return null;

  var paramsArr = paramsStr.split("&");
  if( paramsArr && paramsArr.length > 0 ) {
    var params = {};
    for( var i = 0 ; i < paramsArr.length ; i++ ) {
      var values = /([^=]+)=(.*)/.exec(paramsArr[i]);
      params[values[1]] = values[2];
    }
    return params;
  }
  return null;
}

/**
* Returns the cookie with the specified key
*
* @param String key
*  The key that the cookie was stored with
*/
function getCookie(key) {
  if( key != "" && document.cookie && document.cookie.length ) {
    var cookies = ' ' + document.cookie;
    var start = cookies.indexOf(' ' + key + '=');
    if( start != -1 ) {
      var end = cookies.indexOf(";", start);
      if( end == -1 ) end = cookies.length;
      end -= start;
      var cookie = cookies.substr(start,end);
      return unescape(cookie.substr(cookie.indexOf('=') + 1, cookie.length - cookie.indexOf('=') + 1));
    }
  }
  return "";
}

function byId(id) {
  return document.getElementById(id);
}

function createXmlElement(doc, nodeName, textContent) {
  sysOut("createXmlElement 1, doc: " + doc + ", nodeName: " + nodeName + ", textContent: " + textContent);
  var el = doc.createElement(nodeName);
  sysOut("createXmlElement 2, el: " + el);
  var text = doc.createTextNode(textContent);
  sysOut("createXmlElement 3, text: " + text);
  el.appendChild(text);
  sysOut("createXmlElement 4, el: " + el);
  return el;
}

function createXmlDocument(str) {
  if( boot.isIE ) {
    var doc = new ActiveXObject("Msxml2.FreeThreadedDOMDocument.6.0");
    if( doc ) {
      doc.setProperty("AllowDocumentFunction", true);
      doc.setProperty("AllowXsltScript", true);
      doc.setProperty("SelectionLanguage", "XPath");
      doc.resolveExternals = true;
      if( str ) {
        doc.async = false;
        doc.loadXML(str);
      }
    }
    return doc;
  } else {
    var parser = new DOMParser();
    return parser.parseFromString(str || "", "text/xml");
  }
}

function sysAlert(title, message, closeWin) {

  message = message.replace(/<p>/g, "\n\n");
  message = title + "\n\n" + message;

  alert(message);
  if( closeWin ) {
    top.close();
  }
  return;
  /*
  window.frames["fraAlert"].document.getElementById("windowTitle").innerHTML = title;
  window.frames["fraAlert"].document.getElementById("spanOutMessage").innerHTML = message;
  byId("GUI_Dialog_9_iframe_bg").style.display = "block";
  byId("GUI_Dialog_9_iframe").style.display = "block";
  window.frames["fraAlert"].closeWin = closeWin;
  */
}

function sysAlertClose() {
  window.frames["fraAlert"].document.getElementById("spanOutMessage").innerHTML = "";
  byId("GUI_Dialog_9_iframe_bg").style.display = "none";
  byId("GUI_Dialog_9_iframe").style.display = "none";
}

function sysOut(str, key) {
  if( DEBUG_ON ) {
    var k = outCounter;
    if( key ) {
      k = key;
    }
    byId("divOut").innerHTML += '<div><b style="color: blue;">' + k + '</b>: ' + str + '</div>';
    outCounter++;
  }
}
var outCounter = 0;

function parseUrl(url) {
  if( !window.locationHref ) {
    window.locationHref = window.location.href;
  }
  var rx = /(https{0,1}:\/\/)(.*?)\/.*?\?(.*)/;
  var matches = window.locationHref.match(rx);
  var protocol = matches[1];
  var host = matches[2];

  var result = { host: ( host.indexOf("localhost") == 0 ? "192.168.254.14" : host), protocol: protocol };

  var params = getUrlParams(matches[3]);

  if( params ) {

    if( params["user"] ) {
      result.user = params["user"];
    } else {
      sysAlert("No user id provided.", "No user id provided.");
    }

    result.key = params["key"];
    if( result.key ) {
      result.isNew = false;
    } else {
      result.isNew = true;
    }

    result.session = params["session"];
    result.params = params;
  }

  return result;
}

function serializeXML(node) {
  if( typeof XMLSerializer != "undefined" ) {
    return (new XMLSerializer()).serializeToString(node);
  } else if( node.xml ) return node.xml;
  else throw "XML.serialize is not supported or can't serialize " + node;
};


function hasSessionCookie() {
  //return (document.cookie && (document.cookie.indexOf("session") > -1));
  return true;
}

function isLoginAction(headers) {
  return (headers && headers["SOAPAction"] == "login");
}
