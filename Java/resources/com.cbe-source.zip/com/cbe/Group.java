package com.cbe;

/**
 * Class Group, API requests to server/edge node, for creating/joining and managing groups.
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class Group {

  /**
   * Returns the name of the group.
   */
  public String name() {}

  /**
   * Returns the id of the group.
   */
  public long id() {}

  /**
   * Group Parent id.
   */
  public long parentId() {}

  /**
   * Every group has a drive/container where resources can be shared with the members of the group. Works like a shared container.
   */
  public Container groupContainer() {}

  /**
   * Visibility of the Group, Public is searchable and Private is not. In this early version you can create Private groups but the ability to invite has been blocked. (work in progress) 
   */
  public int getVisibility() {}

  /**
   * Searched groups is obtained through the GroupQuery response. This list of groups have non-joined and joined groups. <br>
   * Already joined groups can be found on the groupManager-&gt;groups() as well and are cached.<br>
   * The joined bool is used to easily sort out groups in the GroupQuery.
   */
  public boolean joined() {}

  /**
   * Requests to join the group. To retrive the list call listJoinRequests(CBE::GroupDelegatePtr delegate) on the group object.
   */
  public Requests_Vec requests() {}

  /**
   * Create Group, can only be used by admin/owners to create new groups.
   * @param name, String name of the group. <br>
   * @param memberAlias, String creator member alias. <br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   * @param
   */
  public Group createGroup(String name, String memberAlias, GroupEventProtocol delegate, int visibility) {}

  /**
   * Create Group, can only be used by admin/owners to create new groups.
   * @param name, String group name
   * @param memberAlias, String creator member alias
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   */
  public Group createGroup(String name, String memberAlias, GroupEventProtocol delegate) {}

  /**
   * Request to join a group, in this first version All members will be Public, meaning visable for other member inside the group. All groups will also be open so all join requests should be accepted directly.
   * @param alias, String you request of alias in the group. <br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   * @param memberVisibility, int (option 1 or 2) can use Visibility enum class as well. 1 is public and 2 is private. <br>
   * @param applicationComment, String an application message to the group owner/s / admin/s. <br>
   */
  public void join(String alias, GroupEventProtocol delegate, int memberVisibility, String applicationComment) {}

  /**
   * Request to join a group, in this first version All members will be Public, meaning visable for other member inside the group. All groups will also be open so all join requests should be accepted directly.
   * @param alias, String you request of alias in the group. <br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   * @param memberVisibility, int (option 1 or 2) can use Visibility enum class as well. 1 is public and 2 is private. <br>
   */
  public void join(String alias, GroupEventProtocol delegate, int memberVisibility) {}

  /**
   * Request to join a group, in this first version All members will be Public, meaning visable for other member inside the group. All groups will also be open so all join requests should be accepted directly.
   * @param alias, String you request of alias in the group. <br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   */
  public void join(String alias, GroupEventProtocol delegate) {}

  /**
   * Leave group.
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   */
  public void leave(GroupEventProtocol delegate) {}

  /**
   * Remove group (exlusive for group owners).
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   */
  public void remove(GroupEventProtocol delegate) {}

  /**
   * Rename the Group, group id does not change.
   * @param newName, String new name of the group <br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   */
  public void rename(String newName, GroupEventProtocol delegate) {}

  /**
   * List all members in the group. After listing, all members will be available though a call to group-&gt;members().
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   */
  public void listMembers(GroupEventProtocol delegate) {}

  /**
   * Lists all banned former members, or users.
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   */
  public void listBannedMembers(GroupEventProtocol delegate) {}

  /**
   * Group Constructor.
   */
  public Group() {}

}
