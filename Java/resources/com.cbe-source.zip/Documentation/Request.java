

package com.cbe;

/**
 * Class Request, is a support class for futer use on group join requests. <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class Request {

  public void setUserId(long value) {}

  public long getUserId() {}

  public void setAlias(String value) {}

  public String getAlias() {}

  public void setApplicationComment(String value) {}

  public String getApplicationComment() {}

  public void setDate(long value) {}

  public long getDate() {}

  public Request() {}

}
