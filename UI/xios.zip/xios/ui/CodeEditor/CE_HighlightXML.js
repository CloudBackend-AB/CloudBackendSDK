/**
* CE: HighlightXML
*
* Code highlighter for CodeEditor (XML)
*
* @author Linus Forsner, Fredrik Carlbom
*
* @history
* 2008-04-30 FC,LF First initial version
*/

function CE_HighlightXML(CodeEditor) {
  this.codeEditor = CodeEditor;

  this.state = [];
  this.parsedText = [];
}

// variables
CE_HighlightXML.prototype.nameStartChar = "(?:[A-Za-z_]|[^\\x00-\\x7F])";
CE_HighlightXML.prototype.nameChar = "(?:[A-Za-z0-9_.-]|[^\\x00-\\x7F])";
CE_HighlightXML.prototype.nameComponent = CE_HighlightXML.prototype.nameStartChar + CE_HighlightXML.prototype.nameChar + "*";
CE_HighlightXML.prototype.name = CE_HighlightXML.prototype.nameComponent + "(?:\\:" + CE_HighlightXML.prototype.nameComponent + ")?";

CE_HighlightXML.prototype.re_elementStart = new RegExp("^<" + CE_HighlightXML.prototype.name);
CE_HighlightXML.prototype.re_tagName = new RegExp("^(" + CE_HighlightXML.prototype.name + "\\s*)");        // Catches "<dummy" or "<dummy:dummy"
CE_HighlightXML.prototype.re_piStart = new RegExp("^<\\?(" + CE_HighlightXML.prototype.name + "\\s*)");    // Catches "<?dummy" or "<?dummy:dummy"
CE_HighlightXML.prototype.re_cdataStart = new RegExp("^<!\\[CDATA\\[");                                    // Catches "<![CDATA["
CE_HighlightXML.prototype.re_commentStart = new RegExp("^<!--");                                           // Catches "<!--"
CE_HighlightXML.prototype.re_attName = new RegExp("^(\\s*" + CE_HighlightXML.prototype.name + "\\s*)");    // Catches "dummy" or "dummy:dummy" with atleast one space before and any number of spaces after
CE_HighlightXML.prototype.re_attEqual = new RegExp("^(\\s*=\\s*)");                                        // Catches "=" with any number of spaces before and after
CE_HighlightXML.prototype.re_attValue = new RegExp("^(\\s*(?:'[^'<]*'|\"[^\"<]*\"))");                     // Catches "anything" (including the quotationmarks) or 'anything' with any number of spaces before
CE_HighlightXML.prototype.re_attInside = new RegExp("^(\\s*(?:'[^'<]*|\"[^\"<]*))");                     // Catches "anything" (including the quotationmarks) or 'anything' with any number of spaces before
CE_HighlightXML.prototype.re_elementEnd = new RegExp("^(\\s*/?>)");                                        // Catches ">" or "/>" with any number of spaces before
CE_HighlightXML.prototype.re_piEnd = new RegExp("^(\\s*\\?>)");                                            // Catches "?>" with any number of spaces before
CE_HighlightXML.prototype.re_cdataEnd = new RegExp("^(.*?\\]\\]>)");                                       // Catches "]]>" with any number of characters before
CE_HighlightXML.prototype.re_commentEnd = new RegExp("^((?:.*?[^-])?-->)");                                // Catches "-->" with any number of characters before but doesn't capture --->
CE_HighlightXML.prototype.re_elementClosingTag = new RegExp("^</(\\s*" + CE_HighlightXML.prototype.name + "\\s*)>"); //Catches "</dummy>" or "</dummy:dummy>" with any number of spaces inside the tag

CE_HighlightXML.prototype.TEXT_STATE = 1;
CE_HighlightXML.prototype.ELEMENT_STATE = 2;
CE_HighlightXML.prototype.ELEMENT_ATT_BEFORE_EQUAL_STATE = 3;
CE_HighlightXML.prototype.ELEMENT_ATT_AFTER_EQUAL_STATE = 4;
CE_HighlightXML.prototype.PI_STATE = 5;
CE_HighlightXML.prototype.PI_ATT_BEFORE_EQUAL_STATE = 6;
CE_HighlightXML.prototype.PI_ATT_AFTER_EQUAL_STATE = 7;
CE_HighlightXML.prototype.CDATA_STATE = 10;
CE_HighlightXML.prototype.COMMENT_STATE = 11;
CE_HighlightXML.prototype.TAGNAME_STATE = 12;
CE_HighlightXML.prototype.ELEMENT_ATT_INSIDE_VALUE = 13;

CE_HighlightXML.prototype.value = new String();

// functions
CE_HighlightXML.prototype.parseText = CE_HighlightXML_parseText;
CE_HighlightXML.prototype.parse = CE_HighlightXML_parse;
CE_HighlightXML.prototype.toHTML = CE_HighlightXML_toHTML;
CE_HighlightXML.prototype.newLine = CE_HighlightXML_newLine;
CE_HighlightXML.prototype.removeLine = CE_HighlightXML_removeLine;
CE_HighlightXML.prototype.stateAtCursor = CE_HighlightXML_stateAtCursor;

/**
* Parses the input text.
*
* @param Array txt
*  the text split by row into an array
*/
function CE_HighlightXML_parse(txt) {
  var textLength = txt.length;
  var returnVal;
  delete this.parsedText;
  this.parsedText = [];

  this.state[0] = 1;
  for( this.row = 0; this.row < textLength; this.row++ ) {
    if( txt[this.row] == "" ) txt[this.row] = " ";
    returnVal = this.parseText(txt[this.row], this.state[this.row])
    this.state[this.row+1] = returnVal[0];
    this.parsedText[this.row] = returnVal[1];
  }
}

/**
* Highlight the text
*
* @param String text
*  the text to be parsed.
*
* @param Integer state
*  the state of previous line-end.
*
* @returns Array
*  An array containing the state of the line-end and the highlighted text.
*/
function CE_HighlightXML_parseText(text, state) {
  var length = 0;
  var returnString = [];

  while (text.length != 0) {
    switch (state) {
      case this.TEXT_STATE: // Strip away all text, after that look for {ELEMENT START, PI START, CDATA START, COMMENT START}
        if (text.charAt(0) != '<') {
          var matcher = text.match(/^[^<]*/)
          var len = matcher[0].length;
          returnString.push(this.toHTML(text.substring(0, len)));
          text = text.replace(/^[^<]*/, '');
        }
        if ( this.re_elementStart.test(text) ) {
          returnString.push('<span class="m">&lt;</span>');
          state = this.TAGNAME_STATE;
          text = text.replace(/^</, '');
          break;
        } else if ( this.re_elementClosingTag.test(text) ) {
          returnString.push('<span class="m">&lt;/</span><span class="k1">' + this.toHTML(RegExp.$1) + '</span><span class="m">&gt;</span>');
          state = this.TEXT_STATE;
          text = text.replace(this.re_elementClosingTag, '');
        } else if ( this.re_commentStart.test(text) ) {
          returnString.push('<span class="c1">&lt;!--</span>');
          state = this.COMMENT_STATE;
          text = text.replace(this.re_commentStart, '');
        } else if ( this.re_piStart.test(text) ) {
          returnString.push('<span class="m">&lt;?</span><span class="k1">' + this.toHTML(RegExp.$1) + '</span>');
          state = this.PI_STATE;
          text = text.replace(this.re_piStart, '');
        } else if ( this.re_cdataStart.test(text) ) {
          returnString.push('<span class="c2">&lt;![CDATA[</span>');
          state = this.CDATA_STATE;
          text = text.replace(this.re_cdataStart, '');
        } else {
          returnString.push(this.toHTML(text.substring(0, 1)));
          text = text.substr(1);
        }
        break;
      case this.TAGNAME_STATE: // Look for TAG NAME
        //First look for tag name
        if( this.re_tagName.test(text) ) {
          returnString.push('<span class="k1">' + this.toHTML(RegExp.$1) + '</span>');
          state = this.ELEMENT_STATE;
          text = text.replace(this.re_tagName, '');
          break;
        //then look for other stuff (just for highlight, not correct xml)
        } else {
          state = this.ELEMENT_STATE;
        }
      case this.ELEMENT_STATE: // Look for ATTRIBUTESTART or ELEMENT END;
        //First look for attribute
        if( this.re_attName.test(text) ) {
          returnString.push('<span class="o">' + this.toHTML(RegExp.$1) + '</span>');
          state = this.ELEMENT_ATT_BEFORE_EQUAL_STATE;
          text = text.replace(this.re_attName, '');
          break;
        //then look for > or />.
        } else if( this.re_elementEnd.test(text) ) {
          returnString.push('<span class="m">' + this.toHTML(RegExp.$1) + '</span>');
          state = this.TEXT_STATE;
          text = text.replace(this.re_elementEnd, '');
          break;
        //look for <
        } else if( this.re_elementStart.test(text) ) {
          returnString.push('<span class="m">&lt;</span>');
          state = this.TAGNAME_STATE;
          text = text.substr(1);
          break;
        // then look for other stuff (just for highlight, not correct xml)
        } else {
          state = this.TEXT_STATE;
          break;
        }
      case this.ELEMENT_ATT_BEFORE_EQUAL_STATE: // Look for EQUAL
        if( this.re_attEqual.test(text) ) {
          returnString.push('<span class="d">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_attEqual, '');
          state = this.ELEMENT_ATT_AFTER_EQUAL_STATE;
          break;

        } else {

        }
      case this.ELEMENT_ATT_AFTER_EQUAL_STATE: // Look for ATTRIBUTE VALUE
        //First look for attribute value
        if( this.re_attValue.test(text) ) {
          returnString.push('<span class="l">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_attValue, '');
        //if it doesnt find any go back to element state.
        }
        state = this.ELEMENT_STATE;
        break;
      case this.PI_STATE: // Look for ATTRIBUTESTART or PI END;
        if( this.re_attName.test(text) ) {
          returnString.push('<span class="o">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_attName, '');
          state = this.PI_ATT_BEFORE_EQUAL_STATE;
          break;
        } else if( this.re_piEnd.test(text) ) {
          returnString.push('<span class="m">?&gt;</span>');
          text = text.replace(this.re_piEnd, '');
          state = this.TEXT_STATE;
          break;
        } else {

        }
      case this.PI_ATT_BEFORE_EQUAL_STATE: // Look for EQUAL
        if( this.re_attEqual.test(text) ) {
          returnString.push('<span class="d">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_attEqual, '');
          state = this.PI_ATT_AFTER_EQUAL_STATE;
          break;
        } else {
          state = this.PI_STATE;
        }
      case this.PI_ATT_AFTER_EQUAL_STATE: // Look for ATTRIBUTE VALUE
        if( this.re_attValue.test(text) ) {
          returnString.push('<span class="l">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_attValue, '');
          state = this.PI_STATE;
          break;

        } else {
          state = this.PI_STATE;
        }
      case this.COMMENT_STATE: // Look for COMMENT END;
        if( this.re_commentEnd.test(text) ) {
          returnString.push('<span class="c1">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_commentEnd, '');
          state = this.TEXT_STATE;

        } else {
          length = text.length;
          returnString.push('<span class="c1">' + this.toHTML(text) + '</span>');
          text = "";

        }
        break;
      case this.CDATA_STATE: // Look for CDATA END;
        if( this.re_cdataEnd.test(text) ) {
          returnString.push('<span class="c2">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_cdataEnd, '');
          state = this.TEXT_STATE;

        } else {
          length = text.length;
          returnString.push('<span class="c2">' + this.toHTML(text) + '</span>');
          text = "";
        }
        break;
    }
  }

  return [state, returnString.join('')];
}

/**
* Transforms the input text to valid HTML
*
* @param String text
*  the input text.
*
* @returns String
*  the text with valid HTML
*/
function CE_HighlightXML_toHTML(text) {
  return text.replace(/&/g, "&amp;").replace(/ /g, "&nbsp;").replace(/\>/g, "&gt;").replace(/\</g, "&lt;");
}

/**
* Inserts a new line in the parsedText.
*
* @param Integer line
*  at what line to insert a new one.
*/
function CE_HighlightXML_newLine(line) {
  var state = this.state[line];
  var text = '&nbsp';
  this.state.splice(line, 0, state);
  this.parsedText.splice(line, 0, text);
}

/**
* Removes a new line in the parsedText.
*
* @param Integer line
*  what line to remove.
*/
function CE_HighlightXML_removeLine(line) {
  this.state.splice(line, 1);
  this.parsedText.splice(line, 1);
}

/**
* Gets the state at the caret/cursor position
*
* @param String text
*  the text to be checked.
*
* @param Integer state
*  the state of previous line-end.
*
* @returns Integer
*  the state at the end of the text.
*/
function CE_HighlightXML_stateAtCursor(text, state) {
  while (text.length != 0) {
    switch (state) {
      case this.TEXT_STATE: // Strip away all text, after that look for {ELEMENT START, PI START, CDATA START, COMMENT START}
        if (text.charAt(0) != '<') {
          text = text.replace(/^[^<]*/, '');
        }
        if ( this.re_elementStart.test(text) ) {
          state = this.TAGNAME_STATE;
          text = text.replace(/^</, '');
          break;
        } else if ( this.re_elementClosingTag.test(text) ) {
          state = this.TEXT_STATE;
          text = text.replace(this.re_elementClosingTag, '');
        } else if ( this.re_commentStart.test(text) ) {
          state = this.COMMENT_STATE;
          text = text.replace(this.re_commentStart, '');
        } else if ( this.re_piStart.test(text) ) {
          state = this.PI_STATE;
          text = text.replace(this.re_piStart, '');
        } else if ( this.re_cdataStart.test(text) ) {
          state = this.CDATA_STATE;
          text = text.replace(this.re_cdataStart, '');
        } else {
          text = text.substr(1);
        }
        break;
      case this.TAGNAME_STATE: // Look for TAG NAME
        if( this.re_tagName.test(text) ) {
          state = this.ELEMENT_STATE;
          text = text.replace(this.re_tagName, '');
          break;
        } else {
          text = "";
          break;
        }
      case this.ELEMENT_STATE: // Look for ATTRIBUTESTART or ELEMENT END;
        if( this.re_attName.test(text) ) {
          state = this.ELEMENT_ATT_BEFORE_EQUAL_STATE;
          text = text.replace(this.re_attName, '');
          break;
        } else if( this.re_elementEnd.test(text) ) {
          state = this.TEXT_STATE;
          text = text.replace(this.re_elementEnd, '');
          break;
        } /*else if( this.re_elementStart.test(text) ) {
          state = this.TAGNAME_STATE;
          text = text.substr(1);
          break;
        }*/ else {
          text = "";
          break;
        }
      case this.ELEMENT_ATT_BEFORE_EQUAL_STATE: // Look for EQUAL
        if( this.re_attEqual.test(text) ) {
          text = text.replace(this.re_attEqual, '');
          state = this.ELEMENT_ATT_AFTER_EQUAL_STATE;
          break;
        } else {
          text = "";
          break;
        }
      case this.ELEMENT_ATT_AFTER_EQUAL_STATE: // Look for ATTRIBUTE VALUE
        if( this.re_attValue.test(text) ) {
          text = text.replace(this.re_attValue, '');
          state = this.ELEMENT_STATE;
        } else if( this.re_attInside.test(text) ) {
          state = this.ELEMENT_ATT_INSIDE_VALUE;
          text = text.replace(this.re_attInside, '');
        } else {
          text = "";
        }
        break;
      case this.PI_STATE: // Look for ATTRIBUTESTART or PI END;
        if( this.re_attName.test(text) ) {
          text = text.replace(this.re_attName, '');
          state = this.PI_ATT_BEFORE_EQUAL_STATE;
          break;
        } else if( this.re_piEnd.test(text) ) {
          text = text.replace(this.re_piEnd, '');
          state = this.TEXT_STATE;
          break;
        } else {
          text ="";
          break;
        }
      case this.PI_ATT_BEFORE_EQUAL_STATE: // Look for EQUAL
        if( this.re_attEqual.test(text) ) {
          text = text.replace(this.re_attEqual, '');
          state = this.PI_ATT_AFTER_EQUAL_STATE;
          break;
        } else {
          text = "";
          break;
        }
      case this.PI_ATT_AFTER_EQUAL_STATE: // Look for ATTRIBUTE VALUE
        if( this.re_attValue.test(text) ) {
          text = text.replace(this.re_attValue, '');
          state = this.PI_STATE;
          break;

        } else {
          text = "";
          break;
        }
      case this.COMMENT_STATE: // Look for COMMENT END;
        if( this.re_commentEnd.test(text) ) {
          text = text.replace(this.re_commentEnd, '');
          state = this.TEXT_STATE;

        } else {
          text = "";
        }
        break;
      case this.CDATA_STATE: // Look for CDATA END;
        if( this.re_cdataEnd.test(text) ) {
          text = text.replace(this.re_cdataEnd, '');
          state = this.TEXT_STATE;

        } else {
          length = text.length;
          text = "";
        }
        break;
    }
  }
  return state;
}
