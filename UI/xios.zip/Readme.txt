
                      XIOS/3 Application Platform

1. Quick Start

  Copy index.html and the xios directory to the root of a web
  server. Use a standard web browser to visit the index.html file to
  start the XIOS/3 command prompt. Type "dev" to enter the development
  documentation application.


2. License

  XIOS/3 is Copyright 2021 XIOS/3 AB. All rights reserved. This release
  of XIOS/3 is for evaluation purposes only and may not be used in
  production systems. Distribution is prohibited.


3. Third party components

  The party code is included from the xios/external directory.


3.1. Datejs

  Datejs enhances the javascript Date object. Released under Apache
  License. More infomation at http://www.datejs.com/

  Copyright 2008-2015 Object.NET, Inc.

  Licensed under the Apache License, Version 2.0 (the "License"); you
  may not use this file except in compliance with the License.  You
  may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
  implied.  See the License for the specific language governing
  permissions and limitations under the License.

  Contact:
    http://object.net
    hello@object.net
    +1(888)775-5888


3.2. TinyMCE

  TinyMCE is a rich-text editor released under GNU LGPL 2.1
  license. More information at https://github.com/tinymce/tinymce

  Full license text in xios/external/tiny_mce/license.txt


3.3. Promise

  Promise polyfill for IE. Released under MIT license. More
  information at https://github.com/taylorhakes/promise-polyfill

  Copyright (c) 2014 Taylor Hakes
  Copyright (c) 2014 Forbes Lindesay

  Permission is hereby granted, free of charge, to any person
  obtaining a copy of this software and associated documentation files
  (the "Software"), to deal in the Software without restriction,
  including without limitation the rights to use, copy, modify, merge,
  publish, distribute, sublicense, and/or sell copies of the Software,
  and to permit persons to whom the Software is furnished to do so,
  subject to the following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.


3.4. Wicked Good XPath

  XPath polyfill for IE. Released under MIT license. More information
  at https://github.com/google/wicked-good-xpath

  The MIT License

  Copyright (c) 2007 Cybozu Labs, Inc.
  Copyright (c) 2012 Google Inc.

  Permission is hereby granted, free of charge, to any person
  obtaining a copy of this software and associated documentation files
  (the "Software"), to deal in the Software without restriction,
  including without limitation the rights to use, copy, modify, merge,
  publish, distribute, sublicense, and/or sell copies of the Software,
  and to permit persons to whom the Software is furnished to do so,
  subject to the following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.


3.5 Normalize CSS

  Normalization of CSS rules. Released under MIT license. More
  information at https://github.com/necolas/normalize.css


3.6 tiny-js-md5

  Implementation of the cryptographic hash MD5. Released under smiley
  licence. More information at https://github.com/floo51/tiny-js-md5

  These scripts are licensed under the :) licence, so basically you're
  free to use them however you please - feel free to use or modify
  them in whatever way you like. You don't have to explicitly credit
  me (but if you do then I won't complain), but just don't pass them
  off as entirely your own, ok? That's just not cool.


4. Deployment

  Chrome expects XSLT files (".xsl") to be of the MIME content type
  "text/xsl".
