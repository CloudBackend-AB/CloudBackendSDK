package com.cbe;

/**
 * class GroupManager, API:s for listing groups. <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class GroupManager {

  /**
   * List all current joined groups. 
   */
  public void listGroups(GroupEventProtocol delegate) {}

  /**
   * Search for open public groups.<br>
   * @param filter is a group filter to set search criteria for open public groups. Look att class GroupFilter for more information.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   * @param parentGroupId is the id of the group to be searched within. if this is not set the tenent id will be used.
   */
  public void searchGroups(GroupFilter filter, GroupEventProtocol delegate, long parentGroupId) {}

  /**
   * Search for open public groups.<br>
   * @param filter is a group filter to set search criteria for open public groups. Look att class GroupFilter for more information.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on GroupEventProtocol. <br>
   * 
   */
  public void searchGroups(GroupFilter filter, GroupEventProtocol delegate) {}

  /**
   * Returns the tenant id of the Tenant user group that the user is in.
   */
  public long getTenantId() {}

}
