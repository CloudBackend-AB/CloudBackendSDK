package com.cbe;

/**
 * Class Object, API:s to create, download and Object management on the server / edge node. <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class Object extends Item {

  /**
   * Move object to either a container or the root container:<br>
   * @param destinationContainerId: destionation container Id.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public void move(long destinationContainerId, ItemEventProtocol delegate) {}

  /**
   * Rename object:<br>
   * @param name string name of the object.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public void rename(String name, ItemEventProtocol delegate) {}

  /**
   * Remove the object from cloud and locally<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public void remove(ItemEventProtocol delegate) {}

  /**
   * Download object with path from a container to local:<br>
   * @param path to where it will be downloaded.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on TransferEventProtocol. <br>
   */
  public void download(String path, TransferEventProtocol delegate) {}

  /**
   * Download object with binary data from contair and passes it to the delegate.  This is data is on the heap and you are responsible for calling delete on it, though we may change it to a shared pointer in the future.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on TransferEventProtocol. <br>
   */
  public void download(TransferEventProtocol delegate) {}

  /**
   * Downloads the stream # with stream id, to a path of the your choice. To get which streams are added on a object use getStream.   <br>
   * @param path: Select which path you want to download the stream to.<br>
   * <br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on TransferEventProtocol. <br>
   */
  public void downloadStream(String path, Stream stream, TransferEventProtocol delegate) {}

  /**
   * Adds keyValue data to the existing object, if data has the same name it will be overwritten else itt will add to the existing keyValue on the object.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   * @param metadata: (Optional) Metadata is a map with the keyValue (key), the associated value of that key and if it is indexed or not
   */
  public void updateKeyValues(ItemEventProtocol delegate, Obj_KV_Map metadata) {}

  /**
   * Adds keyValue data to the existing object, if data has the same name it will be overwritten else itt will add to the existing keyValue on the object.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   * 
   */
  public void updateKeyValues(ItemEventProtocol delegate) {}

  /**
   * Returns the streams attached to the Object, use object-&gt;_streams after this call to use the streams e.g in downloadStream.   <br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ItemEventProtocol. <br>
   */
  public void getStreams(ItemEventProtocol delegate) {}

  /**
   * Returns the currently loaded stream / streams attached to the object. (NB if getStreams has not been called then streams() will return NULL).
   */
  public Streams_Vec streams() {}

  /**
   * Returns the mime type of the object e.g xml/text or jpg e.t.c 
   */
  public String getMimeType() {}

  /**
   * Returns the binary length/size of the object.
   */
  public long length() {}

  /**
   * Returns the Object type currently Other | GroupInvite | ShareInvite
   */
  public int getObjectType() {}

  /**
   * Returns all the keyValues
   */
  public Obj_KV_Map keyValues() {}

  /**
   * set the Access control list for the object.<br>
   * <br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ShareEventProtocol. <br> 
   */
  public void setACL(ACL_Map ACL, ShareEventProtocol delegate) {}

  /**
   * get the Access Control List for the Object.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ShareEventProtocol. <br>
   */
  public void getACL(ShareEventProtocol delegate) {}

  /**
   * Share Object to a user. Notifies the user that a share has occured so that the user can check what permissions the've been given. Shareing gives read permissions as of right now but might change in the future.<br>
   * @param toUserGroup takes a user id or group id (lastly named is for the future) and share to.<br>
   * @param description names the specific share between you and the user/group.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ShareEventProtocol. <br>
   */
  public void share(long toUserGroup, String description, ShareEventProtocol delegate) {}

  /**
   * unShare the object to a specific shareId created when sharing. Each share is unique between user/group and the one sharing. This is represented with a unique share id.<br>
   * @param shareId is as mentioned the unique id for a share between the owner and other user/group.<br>
   * @param delegate, delegate is a callback delegate to the user defined/implementation of the callbacks on ShareEventProtocol. <br>
   */
  public void unShare(long shareId, ShareEventProtocol delegate) {}

  public Object() {}

}
