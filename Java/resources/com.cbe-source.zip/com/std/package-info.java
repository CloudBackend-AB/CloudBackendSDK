    /**
     * The CloudBackend standard definitions package for the SDK.
     * 
     * <p>
     * Contains cbe defined extended structures, vectors and maps.
     * </p>
     * @since 2.0
     */
    package com.std;
