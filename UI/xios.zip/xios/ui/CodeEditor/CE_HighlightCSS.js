/**
* CE: HighlightCSS
*
* Code highlighter for CodeEditor (CSS)
*
* @author Linus Forsner, Fredrik Carlbom
*
* @history
* 2008-05-15 FC,LF First initial version
*/

function CE_HighlightCSS(CodeEditor) {
  this.codeEditor = CodeEditor;

  this.state = [];
  this.parsedText = [];
}

// variables
CE_HighlightCSS.prototype.nameStartChar = "(?:[A-Za-z_]|[^\\x00-\\x7F])";
CE_HighlightCSS.prototype.nameChar = "(?:[A-Za-z0-9_.-]|[^\\x00-\\x7F])";
CE_HighlightCSS.prototype.nameComponent = CE_HighlightCSS.prototype.nameStartChar + CE_HighlightCSS.prototype.nameChar + "*";
CE_HighlightCSS.prototype.name = CE_HighlightCSS.prototype.nameComponent + "(?:\\:" + CE_HighlightCSS.prototype.nameComponent + ")?";

CE_HighlightCSS.prototype.keyWords =  'aqua|azimuth|background-attachment|background-color|'+
                                      'background-image|background-position|background-repeat|'+
                                      'background|border-bottom-color|border-bottom-style|'+
                                      'border-bottom-width|border-left-color|border-left-style|'+
                                      'border-left-width|border-right|border-right-color|'+
                                      'border-right-style|border-right-width|border-top-color|'+
                                      'border-top-style|border-top-width|border-bottom|border-collapse|'+
                                      'border-left|border-width|border-color|border-spacing|'+
                                      'border-style|border-top|border|caption-side|'+
                                      'clear|clip|color|content|counter-increment|counter-reset|'+
                                      'cue-after|cue-before|cue|cursor|direction|display|'+
                                      'elevation|empty-cells|float|font-family|font-size|'+
                                      'font-size-adjust|font-stretch|font-style|font-variant|'+
                                      'font-weight|font|height|letter-spacing|line-height|'+
                                      'list-style|list-style-image|list-style-position|list-style-type|'+
                                      'margin-bottom|margin-left|margin-right|margin-top|margin|'+
                                      'marker-offset|marks|max-height|max-width|min-height|'+
                                      'min-width|opacity|orphans|outline|outline-color|outline-style|'+
                                      'outline-width|overflow(?!-)|padding-bottom|padding-left|'+
                                      'padding-right|padding-top|padding|page|page-break-after|'+
                                      'page-break-before|page-break-inside|pause-after|pause-before|'+
                                      'pause|pitch|pitch-range|play-during|position|quotes|'+
                                      'richness|right|size|speak-header|speak-numeral|speak-punctuation|'+
                                      'speak|speech-rate|stress|table-layout|text-align|text-decoration|'+
                                      'text-indent|text-shadow|text-transform|top|unicode-bidi|'+
                                      'vertical-align|visibility|voice-family|volume|white-space|widows|'+
                                      'width|word-spacing|z-index|bottom|left|filter|overflow-y|overflow-x';
CE_HighlightCSS.prototype.values =    'above|absolute|always|armenian|aural|auto|avoid|' +
                                      'baseline|behind|below|bidi-override|black|blue|blink|block|bold|' +
                                      'capitalize|center-left|center-right|center|circle|cjk-ideographic|' +
                                      'close-quote|collapse|condensed|continuous|crop|crosshair|cross|cursive|' +
                                      'dashed|decimal-leading-zero|decimal|default|digits|disc|dotted|double|' +
                                      'e-resize|embed|extra-condensed|extra-expanded|expanded|bolder|both|' +
                                      'fantasy|far-left|far-right|faster|fast|fixed|fuchsia|' +
                                      'georgian|gray|green|groove|hebrew|help|hidden|hide|higher|' +
                                      'high|hiragana-iroha|hiragana|icon|inherit|inline-table|inline|' +
                                      'inset|inside|invert|italic|justify|katakana-iroha|katakana|' +
                                      'landscape|larger|large|left-side|leftwards|level|lighter|lime|' +
                                      'line-through|list-item|loud|lower-alpha|lower-greek|lower-roman|lowercase|' +
                                      'maroon|medium|message-box|middle|mix|monospace|ltr|lower|low|' +
                                      'n-resize|narrower|navy|ne-resize|no-close-quote|no-open-quote|no-repeat|' +
                                      'oblique|olive|once|open-quote|outset|outside|overline|' +
                                      'pointer|portrait|purple|px|none|normal|nowrap|nw-resize|' +
                                      'red|relative|repeat-x|repeat-y|repeat|rgb|ridge|right-side|rightwards|' +
                                      's-resize|sans-serif|scroll|se-resize|semi-condensed|semi-expanded|separate|' +
                                      'serif|show|silent|silver|slow|slower|small-caps|small-caption|smaller|' +
                                      'static|status-bar|super|sw-resize|soft|solid|spell-out|square|' +
                                      'table-caption|table-cell|table-column|table-column-group|table-footer-group|' +
                                      'table-header-group|table-row|table-row-group|teal|text|text-bottom|text-top|' +
                                      'ultra-condensed|ultra-expanded|underline|upper-alpha|upper-latin|upper-roman|uppercase|url|' +
                                      'visible|thick|thin|transparent|w-resize|wait|white|wider|' +
                                      'x-fast|x-high|x-large|x-loud|x-low|x-small|x-soft|xx-large|xx-small|' +
                                      'yellow|yes';

CE_HighlightCSS.prototype.re_keyWord = new RegExp("^(\\s*(?:" + CE_HighlightCSS.prototype.keyWords + ")\\s*)");
CE_HighlightCSS.prototype.re_keyValue = new RegExp("^(\\s*(?:" + CE_HighlightCSS.prototype.values + ")\\s*)");
CE_HighlightCSS.prototype.re_numValue = new RegExp("^(\\s*-?\\d+(?:\\.\\d+)?\\s*(?:px|em|pt|:|%|)?\\s*)");
CE_HighlightCSS.prototype.re_value = new RegExp("^(\\s*(?:[^\\\"'\\};]+|\\\"[^\\\"]*\\\"|'[^']*')\\s*)");
CE_HighlightCSS.prototype.re_important = new RegExp("^(\\s*\\!\\s*important\\s*)");
CE_HighlightCSS.prototype.re_color = new RegExp("^(\\s*#[a-fA-F0-9]{3,6}\\s*)");
CE_HighlightCSS.prototype.re_commentStart = new RegExp("^(\\s*/\\*)");
CE_HighlightCSS.prototype.re_commentEnd = new RegExp("^(.*\\*/\\s*)");
CE_HighlightCSS.prototype.re_name = new RegExp("^(\\s*,?\\s*(?:\\.|#|)?" + CE_HighlightCSS.prototype.name + "\\s*)");
CE_HighlightCSS.prototype.re_atName = new RegExp("^(\\s*@\\s*" + CE_HighlightCSS.prototype.name + "\\s*)");
CE_HighlightCSS.prototype.re_startBracket = new RegExp("^(\\s*{\\s*)");
CE_HighlightCSS.prototype.re_endBracket = new RegExp("^(\\s*}\\s*)");
CE_HighlightCSS.prototype.re_colon = new RegExp("^(\\s*:\\s*)");
CE_HighlightCSS.prototype.re_semicolon = new RegExp("^(\\s*;\\s*)");

CE_HighlightCSS.prototype.TEXT_STATE = 1;
CE_HighlightCSS.prototype.NAME_STATE = 2;
CE_HighlightCSS.prototype.BRACKET_STATE = 3;
CE_HighlightCSS.prototype.KEYWORD_STATE = 4;
CE_HighlightCSS.prototype.COL_STATE = 5;
CE_HighlightCSS.prototype.VALUE_STATE = 6;
CE_HighlightCSS.prototype.AT_STATE = 8;
CE_HighlightCSS.prototype.COMMENT_STATE = 9;
CE_HighlightCSS.prototype.previousState = 1;

CE_HighlightCSS.prototype.value = new String();

// functions
CE_HighlightCSS.prototype.parseText = CE_HighlightCSS_parseText;
CE_HighlightCSS.prototype.parse = CE_HighlightCSS_parse;
CE_HighlightCSS.prototype.toHTML = CE_HighlightCSS_toHTML;
CE_HighlightCSS.prototype.newLine = CE_HighlightCSS_newLine;
CE_HighlightCSS.prototype.removeLine = CE_HighlightCSS_removeLine;
CE_HighlightCSS.prototype.stateAtCursor = CE_HighlightCSS_stateAtCursor;

/**
* Parses the input text.
*
* @param Array txt
*  the text split by row into an array
*/
function CE_HighlightCSS_parse(txt) {
  var textLength = txt.length;
  var returnVal;
  delete this.parsedText;
  this.parsedText = [];

  this.state[0] = 1;
  for( this.row = 0; this.row < textLength; this.row++ ) {
    if( txt[this.row] == "" ) txt[this.row] = " ";
    returnVal = this.parseText(txt[this.row], this.state[this.row])
    this.state[this.row+1] = returnVal[0];
    this.parsedText[this.row] = returnVal[1];
  }
}

/**
* Highlight the text
*
* @param String text
*  the text to be parsed.
*
* @param Integer state
*  the state of previous line-end.
*
* @returns Array
*  An array containing the state of the line-end and the highlighted text.
*/
function CE_HighlightCSS_parseText(text, state) {
  var returnString = [];

  while (text.length != 0) {
    switch (state) {
      case this.TEXT_STATE: // look for { name, @, strip rest?}
        if( this.re_name.test(text) ) {
          returnString.push('<span class="f">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_name, '');
          state = this.NAME_STATE;
        } else if( this.re_atName.test(text) ) {
          returnString.push('<span class="m">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_atName, '');
          state = this.AT_STATE;
        } else if( this.re_commentStart.test(text) ) {
          returnString.push('<span class="c1">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_commentStart, '');
          state = this.COMMENT_STATE;
        } else {
          returnString.push(this.toHTML(text));
          text = "";
        }
        break;
      case this.NAME_STATE: // look for { {, name }
        if( this.re_startBracket.test(text) ) {
          returnString.push('<span class="d">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_startBracket, '');
          state = this.BRACKET_STATE;
        } else if( this.re_name.test(text) ) {
          returnString.push('<span class="f">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_name, '');
          state = this.NAME_STATE;
        } else {
          this.previousState = state;
          state = this.TEXT_STATE;
        }
        break;
      case this.BRACKET_STATE: // look for { Keyword, } }
        if( this.re_keyWord.test(text) ) {
          returnString.push('<span class="k1">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_keyWord, '');
          state = this.KEYWORD_STATE;
        } else if( this.re_endBracket.test(text) ) {
          returnString.push('<span class="d">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_endBracket, '');
          state = this.TEXT_STATE;
          this.previousState = this.TEXT_STATE;
        } else {
          this.previousState = state;
          state = this.TEXT_STATE;
        }
        break;
      case this.KEYWORD_STATE: // look for { :, } }
        if( this.re_colon.test(text) ) {
          returnString.push('<span class="d">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_colon, '');
          state = this.COL_STATE;
        } else if( this.re_endBracket.test(text) ) {
          returnString.push('<span class="d">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_endBracket, '');
          state = this.TEXT_STATE;
          this.previousState = this.TEXT_STATE;
        } else {
          this.previousState = state;
          state = this.TEXT_STATE;
        }
        break;
      case this.COL_STATE: // look for { values, !important }
        if( this.re_keyValue.test(text) ) {
          returnString.push('<span class="k2">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_keyValue, '');
          state = this.VALUE_STATE;
        } else if( this.re_numValue.test(text) ) {
          returnString.push('<span class="k4">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_numValue, '');
          state = this.VALUE_STATE;
        } else if( this.re_color.test(text) ) {
          returnString.push('<span class="k3">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_color, '');
          state = this.VALUE_STATE;
        } else if( this.re_important.test(text) ) {
          returnString.push('<span class="k1">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_important, '');
          state = this.VALUE_STATE;
        } else if( this.re_value.test(text) ) {
          returnString.push('<span class="k2">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_value, '');
          state = this.VALUE_STATE;
        } else {
          this.previousState = state;
          state = this.TEXT_STATE;
        }
        break;
      case this.VALUE_STATE: // look for { value, ;, } }
        if( this.re_keyValue.test(text) ) {
          returnString.push('<span class="k2">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_keyValue, '');
          state = this.VALUE_STATE;
        } else if( this.re_numValue.test(text) ) {
          returnString.push('<span class="k4">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_numValue, '');
          state = this.VALUE_STATE;
        } else if( this.re_color.test(text) ) {
          returnString.push('<span class="k3">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_color, '');
          state = this.VALUE_STATE;
        } else if( this.re_important.test(text) ) {
          returnString.push('<span class="k1">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_important, '');
          state = this.VALUE_STATE;
        } else if( this.re_value.test(text) ) {
          returnString.push('<span class="k2">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_value, '');
          state = this.VALUE_STATE;
        } else if( this.re_semicolon.test(text) ) {
          returnString.push('<span class="d">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_semicolon, '');
          state = this.BRACKET_STATE;
        } else if( this.re_endBracket.test(text) ) {
          returnString.push('<span class="d">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_endBracket, '');
          this.previousState = this.TEXT_STATE;
          state = this.TEXT_STATE;
        } else {
          this.previousState = state;
          state = this.TEXT_STATE;
        }
        break;
      case this.AT_STATE: // look for { ; }
        if( this.re_endBracket.test(text) ) {
          returnString.push('<span class="d">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_endBracket, '');
          state = this.TEXT_STATE;
        } else {
          this.previousState = state;
          state = this.TEXT_STATE;
        }
        break;
      case this.COMMENT_STATE: // look for { */ }
        if( this.re_commentEnd.test(text) ) {
          returnString.push('<span class="c1">' + this.toHTML(RegExp.$1) + '</span>');
          text = text.replace(this.re_commentEnd, '');
          state = this.previousState;
        } else {
          returnString.push('<span class="c1">' + this.toHTML(text) + '</span>');
          text = "";
        }
        break;
    }
  }

  return [state, returnString.join('')];
}

/**
* Transforms the input text to valid HTML
*
* @param String text
*  the input text.
*
* @returns String
*  the text with valid HTML
*/
function CE_HighlightCSS_toHTML(text) {
  return text.replace(/&/g, "&amp;").replace(/ /g, "&#160;").replace(/\>/g, "&gt;").replace(/\</g, "&lt;");
}

/**
* Inserts a new line in the parsedText.
*
* @param Integer line
*  at what line to insert a new one.
*/
function CE_HighlightCSS_newLine(line) {
  var state = this.state[line];
  var text = '&nbsp';
  this.state.splice(line, 0, state);
  this.parsedText.splice(line, 0, text);
}

/**
* Removes a new line in the parsedText.
*
* @param Integer line
*  what line to remove.
*/
function CE_HighlightCSS_removeLine(line) {
  this.state.splice(line, 1);
  this.parsedText.splice(line, 1);
}

/**
* Gets the state at the caret/cursor position
*
* @param String text
*  the text to be checked.
*
* @param Integer state
*  the state of previous line-end.
*
* @returns Integer
*  the state at the end of the text.
*/
function CE_HighlightCSS_stateAtCursor(text, state) {
  return 1;
}
