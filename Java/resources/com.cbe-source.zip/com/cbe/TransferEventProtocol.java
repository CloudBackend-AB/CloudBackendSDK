package com.cbe;

/**
 * Protocol for implementing a  transfer delegate.<br>
 * Abstract base class which is used when you want notification on
 * changes related to uploads and downloads calls. Note this class needs to be implemented by the user. <br>
 * @author CloudBackend. <br>
 * @version 1.4.6 <br>
 */
public class TransferEventProtocol {
  /**
   * Gets called when a upload has been completed. 
   */
  public void onObjectUploaded(Object object) {}

  /**
   *  Gets called when a error has occured in the upload stream. 
   */
  public void onObjectUploadFailed(String name, long objectId, long parentId, long atState, long status) {}

  /**
   *  Gets called when a chunk of data has successfully been recieved. 
   */
  public void onChunkSent(Object object, long sent, long total) {}

  /**
   *  Gets called when a chunk of data has successfully been recieved. 
   */
  public void onChunkReceived(Object object, long received, long total) {}

  /**
   *  Gets called when a download has completed. 
   */
  public void onObjectDownloaded(Object object, String path) {}

  /**
   *  Gets called when a download has completed.  IMPORTANT!!   This data is on the heap and you are responsible for calling delete on it.  We may change data to a shared pointer in the future. 
   */
  public void onObjectBinaryDownloaded(Object object, byte[] data) {}

  /**
   *  Gets called when a error has occured in the download stream 
   */
  public void onObjectDownloadFailed(Object object, long status) {}

  public TransferEventProtocol() {}

}
