package com.cbe;
/**
 * class Account, getter functions for account information.
 * @author Cloudbackend
 * @version 1.4.6
 */
public class Account {

  /**
   *  Returns the account id of the user. 
   */
  public long userId() {}

  /**
   *  Returns the username of the account.
   */
  public String username() {}

  /**
   *  Returns the password of the account.
   */
  public String password() {}

  /**
   *  Returns the source of the account.
   */
  public String source() {}

  /**
   *  Returns the name of the user.
   */
  public String firstName() {}

  /**
   *  Returns the surname of the user.
   */
  public String lastName() {}

  /**
   *  Returns the rootContainer for the account
   */
  public Container rootContainer() {}

  /**
   *  Returns the libContainerId for the account.  For more information about libContainers see documentation.
   */
  public long containerId() {}

  /**
   *  Returns the rootContainerId for the account
   */
  public long rootDriveId() {}

}
