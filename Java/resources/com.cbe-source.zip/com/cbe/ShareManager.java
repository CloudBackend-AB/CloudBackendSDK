

package com.cbe;

/**
 * Class for Managing Shares.<br>
 * This is class has API calls for listing of Shares. <br>
 * @author CloudBackend AB
 * @version 1.4.6
 */
public class ShareManager {

  /**
   * lists shares that have been shared to you. this will give you information similar to a query but with specific share information.<br>
   * @param delegate, ShareDelegate is a callback delegate to the user defined/implementation of the callbacks on ShareEventProtocol. <br>
   */
  public void listAvailableShares(ShareEventProtocol delegate) {}

  /**
   * lists shares that have been shared by you. this will give you information similar to a query but with specific share information.<br>
   * @param delegate, ShareDelegate is a callback delegate to the user defined/implementation of the callbacks on ShareEventProtocol. <br>
   */
  public void listMyShares(ShareEventProtocol delegate) {}

}
