package com.cbe;

/**
 * Protocol for implementing a  transfer upload delegate.<br>
 * Abstract base class which is used when you want notification on
 * changes related to uploads. Note this class needs to be implemented by the user. <br>
 * @author CloudBackend. <br>
 * @version 1.4.6 <br>
 */

public class TransferUploadEventProtocol {

  /**
   * call delete on the delegate if you want garbage collector to clean up.
   */
  public synchronized void delete() {}

  /**
   * Gets called when a upload has been completed. 
   */
  public void onObjectUploaded(cbe.com.Object object) {}

  /**
   *  Gets called when a error has occured in the upload stream. 
   */
  public void onObjectUploadFailed(String name, long objectId, long parentId, long atState, long status) {}

  /**
   *  Gets called when a chunk of data has successfully been recieved. 
   */
  public void onChunkSent(com.cbe.Object object, long sent, long total) {}

  public TransferUploadEventProtocol() {}

}
