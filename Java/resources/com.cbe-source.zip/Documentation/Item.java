package com.cbe;

/**
 * class Item, parent class for Container and Object.
 * @author Cloudbackend
 * @version 1.4.6
 */
public class Item {

  public ShareInfo_Map getShareIds() {}

  /**
   *  Get the shareId from userId
   *  @param userId long userId is defined both on the account for the specific user but also on items on ownerId. <br>
   *  @return a shareId if there is one set on the Object or Container. 
   */
  public long getShareFromUserId(long userId) {}

  /**
   *  Get the shareId from userId
   *  @param shareId long ShareId is set when a Container or Object has been shared.
   */
  public long getUserFromShareId(long shareId) {}

  /**
   *  returns a string that is used internaly when setting acls
   */
  public String aclTag() {}

  /**
   *  Returns a description of the Item
   */
  public String description() {}

  /**
   *  Returns an Items id. 
   */
  public long id() {}

  /**
   *  Returns the id of the Items parent. 
   */
  public long parentId() {}

  public long oldParentId() {}

  /**
   *  Returns the name. 
   */
  public String name() {}

  /**
   *  Returns the path 
   */
  public String path() {}

  /**
   *  Returns the owner id. 
   */
  public long ownerId() {}

  /**
   *  Returns which drive the container resides on. 
   */
  public long driveId() {}

  /**
   *  Returns the username of the Containers owner. 
   */
  public String username() {}

  /**
   *  used internaly, but returns if an id and data has been loaded from server / edge node.
   */
  public boolean idLoaded() {}

  public boolean dataLoaded() {}

  /**
   *  Returns the creation date in Unix time. 
   */
  public long created() {}

  /**
   * Returns the updated date/time in Unix time
   */
  public long updated() {}

  /**
   *  Returns the deleted date in Unix time
   */
  public long deleted() {}

  /**
   *  Container or Object
   */
  public int type() {}

  /**
   *  ACLs key is user id and int is the acl set 0-15 
   */
  public ACL_Map ACLMap() {}

}
