package com.cbe;
/**
 * Protocol for implementing a  transfer download delegate.<br>
 * Abstract base class which is used when you want notification on
 * changes related to downloads. Note this class needs to be implemented by the user. <br>
 * @author CloudBackend. <br>
 * @version 1.4.6 <br>
 */

public class TransferDownloadEventProtocol {

  /**
   * call delete on the delegate if you want garbage collector to clean up.
   */
  public synchronized void delete() {}

  /**
   *  Gets called when a chunk of data has successfully been recieved. 
   */
  public void onChunkReceived(com.cbe.Object object, long received, long total) {}

  /**
   *  Gets called when a download has completed. 
   */
  public void onObjectDownloaded(com.cbe.Object object, String path) {}

  /**
   *  Gets called when a download has completed.  IMPORTANT!!   This data is on the heap and you are responsible for calling delete on it.  We may change data to a shared pointer in the future. 
   */
  public void onObjectBinaryDownloaded(com.cbe.Object object, byte[] data) {}

  /**
   *  Gets called when a error has occured in the download stream 
   */
  public void onObjectDownloadFailed(com.cbe.Object object, long status) {}

  public TransferDownloadEventProtocol() {}

}
