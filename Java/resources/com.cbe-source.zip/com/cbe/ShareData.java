package com.cbe;

/**
 * Class for share data management. <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class ShareData {

  /** 
   * set userId or groupId depending on if owner is a group or a user. <br>
   * @param value, long id. <br>
  */
  public void setId(long value) {}

  /** Returns the ownerId of the share. <br>*/
  public long getId() {}

  /** 
   * Set if the owner is a userId (true) else if the owner is a group set false. <br>
   * @param value, boolean true if userId, false if groupId <br>
  */
  public void setIsUserId(boolean value) {}

  /** Returns true if userId, else if groupId. <br> */
  public boolean getIsUserId() {}

  /** Constructor, id is set to 0 and isUserId is true. <br>*/
  public ShareData() {}

}
