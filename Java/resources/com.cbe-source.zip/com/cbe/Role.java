package com.cbe;

/**
 * Class Role, originates from a struct on c++ which is made for structuring Role data on the Member class. <br>
 * @author Cloudbackend <br>
 * @version 1.4.6 <br>
 */
public class Role {

  /** Set Role name.*/
  public void setRole(String value) {}

  /** get the Role ex: could be administrator, owner etc.*/
  public String getRole() {}

  /** Constructor.*/
  public Role() {}

}
